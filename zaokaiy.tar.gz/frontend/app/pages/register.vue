<script setup lang="ts">
const { register } = useAuth()
const route = useRoute()
const form = reactive({ display_name: '', email: '', password: '' })
const error = ref('')
const busy = ref(false)
async function submit() {
  error.value = ''
  busy.value = true
  try {
    await register(form.email, form.password, form.display_name)
    await navigateTo((route.query.next as string) || '/dashboard')
  } catch (e) {
    error.value = apiError(e)
  } finally {
    busy.value = false
  }
}
useHead({ title: 'Create account · zaokaiy' })
</script>

<template>
  <div class="mx-auto grid max-w-md px-4 py-16">
    <h1 class="page-title text-3xl">Create your account</h1>
    <p class="mt-1 text-muted">One account to buy, sell, resell and create.</p>
    <form class="card mt-8 space-y-4 p-6" @submit.prevent="submit">
      <div><label class="label">Display name</label><input v-model="form.display_name" required class="input" ></div>
      <div><label class="label">Email</label><input v-model="form.email" type="email" required class="input" autocomplete="email" ></div>
      <div>
        <label class="label">Password</label>
        <input v-model="form.password" type="password" required minlength="8" class="input" autocomplete="new-password" >
        <p class="mt-1 text-xs text-muted">At least 8 characters.</p>
      </div>
      <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
      <button class="btn-primary w-full" :disabled="busy">{{ busy ? 'Creating…' : 'Create account' }}</button>
      <p class="text-center text-sm text-muted">Have an account? <NuxtLink to="/login" class="font-semibold text-ink underline">Log in</NuxtLink></p>
    </form>
  </div>
</template>
