<script setup lang="ts">
import type { CatalogProduct } from '~/utils/types'

const api = useApi()
const route = useRoute()
const q = computed(() => (route.query.q as string) || '')
const category = computed(() => (route.query.category as string) || '')

const { data: products, status } = await useAsyncData(
  'catalog',
  () => api<CatalogProduct[]>('/catalog/products', { query: { q: q.value || undefined, category: category.value || undefined, limit: 48 } }),
  { watch: [q, category], default: () => [] },
)
const { data: categories } = await useAsyncData('categories', () => api<{ category: string; count: number }[]>('/catalog/categories'), {
  default: () => [],
})
const { loggedIn } = useAuth()
</script>

<template>
  <div>
    <section v-if="!q && !category" class="mx-auto max-w-7xl px-4 pt-10">
      <div class="relative overflow-hidden rounded-[2rem] bg-ink px-6 py-14 text-white sm:px-12 sm:py-20">
        <div class="absolute -right-24 -top-24 size-96 rounded-full bg-brand-500/40 blur-3xl" />
        <div class="absolute -bottom-32 left-1/3 size-80 rounded-full bg-sun-400/20 blur-3xl" />
        <div class="relative max-w-2xl">
          <span class="chip bg-white/10 text-white">Social commerce for the new generation</span>
          <h1 class="mt-5 text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
            Open a shop.<br>Let creators <span class="text-brand-500">sell for you.</span>
          </h1>
          <p class="mt-5 max-w-lg text-white/70">
            List your products, track stock, run ads — and open your catalog to sell-staff who earn a commission on every sale. AI writes the content.
          </p>
          <div class="mt-8 flex flex-wrap gap-3">
            <NuxtLink :to="loggedIn ? '/dashboard' : '/register'" class="btn-primary">Start selling — free</NuxtLink>
            <NuxtLink :to="loggedIn ? '/dashboard/marketplace' : '/register'" class="btn bg-white/10 text-white hover:bg-white/20">Become a sell-staff</NuxtLink>
          </div>
        </div>
      </div>
      <div class="mt-6 grid gap-3 sm:grid-cols-3">
        <div v-for="f in [
          ['Own shop', 'Products, inventory and orders in one place.'],
          ['Sell-staff network', 'Approve resellers & creators, set commission per partner.'],
          ['AI growth', 'Captions, video scripts, ads and a shop assistant.'],
        ]" :key="f[0]" class="card p-5">
          <div class="font-bold">{{ f[0] }}</div>
          <div class="mt-1 text-sm text-muted">{{ f[1] }}</div>
        </div>
      </div>
    </section>

    <section class="mx-auto max-w-7xl px-4 pt-10">
      <AdStrip :limit="3" />
    </section>

    <section class="mx-auto max-w-7xl px-4 pt-10">
      <div class="flex flex-wrap items-end justify-between gap-4">
        <h2 class="text-2xl font-extrabold tracking-tight">
          <template v-if="q">Results for “{{ q }}”</template>
          <template v-else-if="category" ><span class="capitalize">{{ category }}</span></template>
          <template v-else>Fresh drops</template>
        </h2>
        <div class="flex flex-wrap gap-2">
          <NuxtLink to="/" class="chip border px-3 py-1" :class="!category ? 'border-ink bg-ink text-white' : 'border-line bg-white'">All</NuxtLink>
          <NuxtLink
            v-for="c in categories"
            :key="c.category"
            :to="{ path: '/', query: { category: c.category } }"
            class="chip border px-3 py-1 capitalize"
            :class="category === c.category ? 'border-ink bg-ink text-white' : 'border-line bg-white'"
          >{{ c.category }}</NuxtLink>
        </div>
      </div>
      <div v-if="status === 'pending'" class="mt-6 grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
        <div v-for="i in 8" :key="i" class="aspect-[4/5] animate-pulse rounded-2xl bg-line/60" />
      </div>
      <div v-else-if="products.length" class="mt-6 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:grid-cols-4">
        <ProductCard v-for="p in products" :key="p.id" :product="p" />
      </div>
      <EmptyState v-else class="mt-6" title="Nothing here yet" text="Be the first to list a product.">
        <NuxtLink to="/dashboard/products/new" class="btn-primary">List a product</NuxtLink>
      </EmptyState>
    </section>
  </div>
</template>
