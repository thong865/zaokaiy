<script setup lang="ts">
import type { CatalogProduct, Content, Shop } from '~/utils/types'

const route = useRoute()
const api = useApi()
const { data, error } = await useAsyncData(`store:${route.params.slug}`, () =>
  api<{ shop: Shop; products: CatalogProduct[]; resold: CatalogProduct[]; contents: Content[] }>(`/storefront/${route.params.slug}`),
)
if (error.value || !data.value) throw createError({ statusCode: 404, statusMessage: 'Shop not found', fatal: true })
const tab = ref<'all' | 'own' | 'picks'>('all')
const list = computed(() => {
  const d = data.value!
  if (tab.value === 'own') return d.products
  if (tab.value === 'picks') return d.resold
  return [...d.products, ...d.resold]
})
useHead({ title: () => `${data.value?.shop.name} · zaokaiy` })
</script>

<template>
  <div v-if="data" class="mx-auto max-w-7xl px-4 pt-10">
    <div class="card flex flex-wrap items-center gap-5 p-6">
      <ProductThumb :src="data.shop.logo_url" :name="data.shop.name" class="size-20" rounded="rounded-3xl" />
      <div class="min-w-0 flex-1">
        <div class="flex items-center gap-2">
          <h1 class="text-2xl font-extrabold tracking-tight">{{ data.shop.name }}</h1>
          <span class="chip bg-brand-50 capitalize text-brand-700">{{ data.shop.kind }}</span>
        </div>
        <p class="mt-1 max-w-2xl text-sm text-muted">{{ data.shop.description || 'Welcome to our shop!' }}</p>
      </div>
      <div class="flex gap-6 text-center text-sm">
        <div><div class="text-xl font-extrabold">{{ data.products.length }}</div><div class="text-muted">Own products</div></div>
        <div><div class="text-xl font-extrabold">{{ data.resold.length }}</div><div class="text-muted">Curated picks</div></div>
      </div>
    </div>

    <div class="mt-8 flex gap-2">
      <button v-for="t in (['all', 'own', 'picks'] as const)" :key="t" class="chip border px-3 py-1.5 capitalize" :class="tab === t ? 'border-ink bg-ink text-white' : 'border-line bg-white'" @click="tab = t">
        {{ t === 'picks' ? 'Curated picks' : t === 'own' ? 'Own products' : 'All' }}
      </button>
    </div>
    <div v-if="list.length" class="mt-6 grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:grid-cols-4">
      <ProductCard v-for="p in list" :key="`${p.id}-${p.via_shop_id}`" :product="p" />
    </div>
    <EmptyState v-else class="mt-6" title="No products yet" />

    <section v-if="data.contents.length" class="mt-14">
      <h2 class="text-xl font-extrabold tracking-tight">From {{ data.shop.name }}</h2>
      <div class="mt-4 grid gap-4 md:grid-cols-3">
        <article v-for="c in data.contents" :key="c.id" class="card p-5">
          <div class="text-[11px] font-bold uppercase tracking-wider text-muted">{{ kindLabel[c.kind] }}</div>
          <h3 class="mt-1 font-bold">{{ c.title }}</h3>
          <p class="mt-2 line-clamp-6 whitespace-pre-line text-sm text-ink/80">{{ c.body }}</p>
        </article>
      </div>
    </section>
  </div>
</template>
