<script setup lang="ts">
import type { Product } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shopId, shop } = useShop()
const busy = ref(false)
const error = ref('')
async function save(body: Record<string, unknown>) {
  busy.value = true
  error.value = ''
  try {
    const p = await api<Product>(`/shops/${shopId.value}/products`, { method: 'POST', body })
    await navigateTo(`/dashboard/products/${p.id}`)
  } catch (e) {
    error.value = apiError(e)
  } finally {
    busy.value = false
  }
}
</script>

<template>
  <div>
    <NuxtLink to="/dashboard/products" class="text-sm text-muted hover:text-ink">← Products</NuxtLink>
    <h1 class="page-title mt-2">New product</h1>
    <p class="mb-6 text-sm text-muted">Tip: save first, then let AI write the description.</p>
    <ProductForm :busy="busy" :currency="shop?.currency" @submit="save">
      <template #after><p v-if="error" class="text-sm text-brand-700">{{ error }}</p></template>
    </ProductForm>
  </div>
</template>
