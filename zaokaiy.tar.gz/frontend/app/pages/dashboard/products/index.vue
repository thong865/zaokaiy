<script setup lang="ts">
import type { Product } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shopId, shop } = useShop()
const q = ref('')
const status = ref('')
const { data: products } = await useAsyncData(
  'products',
  () => api<Product[]>(`/shops/${shopId.value}/products`, { query: { q: q.value || undefined, status: status.value || undefined } }),
  { watch: [shopId, status], default: () => [] },
)
const debounced = refDebounced(q)
watch(debounced, () => refreshNuxtData('products'))

function refDebounced(src: Ref<string>, ms = 300) {
  const out = ref(src.value)
  let t: ReturnType<typeof setTimeout> | undefined
  watch(src, (v) => { clearTimeout(t); t = setTimeout(() => (out.value = v), ms) })
  return out
}
</script>

<template>
  <div>
    <div class="flex flex-wrap items-center justify-between gap-3">
      <h1 class="page-title">Products</h1>
      <NuxtLink to="/dashboard/products/new" class="btn-primary">+ New product</NuxtLink>
    </div>
    <div class="mt-5 flex flex-wrap gap-3">
      <input v-model="q" placeholder="Search name or SKU" class="input max-w-xs" >
      <select v-model="status" class="input w-40">
        <option value="">All statuses</option><option value="active">Active</option><option value="draft">Draft</option><option value="archived">Archived</option>
      </select>
    </div>
    <div v-if="products.length" class="card mt-5 overflow-x-auto">
      <table class="table">
        <thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Sell-staff</th><th>Status</th></tr></thead>
        <tbody>
          <tr v-for="p in products" :key="p.id" class="cursor-pointer hover:bg-paper" @click="navigateTo(`/dashboard/products/${p.id}`)">
            <td>
              <div class="flex items-center gap-3">
                <ProductThumb :src="p.images?.[0]" :name="p.name" class="size-10 shrink-0" rounded="rounded-lg" />
                <div><div class="font-semibold">{{ p.name }}</div><div class="text-xs text-muted">{{ p.sku }} · {{ p.category }}</div></div>
              </div>
            </td>
            <td class="font-semibold">{{ money(p.price_cents, shop?.currency) }}</td>
            <td><span :class="p.stock <= p.low_stock_threshold && 'font-bold text-brand-700'">{{ p.stock }}</span></td>
            <td><span v-if="p.allow_resell" class="chip bg-brand-50 text-brand-700">{{ pct(p.commission_bps) }}</span><span v-else class="text-muted">—</span></td>
            <td><StatusBadge :status="p.status" /></td>
          </tr>
        </tbody>
      </table>
    </div>
    <EmptyState v-else class="mt-5" title="No products" text="Add your first product to start selling.">
      <NuxtLink to="/dashboard/products/new" class="btn-primary">Add product</NuxtLink>
    </EmptyState>
  </div>
</template>
