<script setup lang="ts">
import type { Shop } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shop, shops, createShop } = useShop()
const f = reactive({ name: '', description: '', logo_url: '', kind: 'seller' })
watch(shop, (s) => s && Object.assign(f, { name: s.name, description: s.description, logo_url: s.logo_url ?? '', kind: s.kind }), { immediate: true })
const msg = ref('')
const error = ref('')
async function save() {
  msg.value = error.value = ''
  try {
    const updated = await api<Shop>(`/shops/${shop.value!.id}`, { method: 'PATCH', body: { ...f, logo_url: f.logo_url || null } })
    const i = shops.value.findIndex((s) => s.id === updated.id)
    shops.value[i] = updated
    msg.value = 'Saved'
  } catch (e) {
    error.value = apiError(e)
  }
}
const n = reactive({ name: '', slug: '', kind: 'creator' })
async function addShop() {
  error.value = ''
  try {
    await createShop({ ...n } as never)
    Object.assign(n, { name: '', slug: '' })
  } catch (e) {
    error.value = apiError(e)
  }
}
</script>

<template>
  <div class="max-w-2xl">
    <h1 class="page-title">Shop settings</h1>
    <form class="card mt-6 space-y-4 p-6" @submit.prevent="save">
      <div><label class="label">Name</label><input v-model="f.name" required class="input" ></div>
      <div><label class="label">URL</label><input :value="`/s/${shop?.slug}`" disabled class="input bg-paper" ></div>
      <div><label class="label">About</label><textarea v-model="f.description" rows="4" class="input" /></div>
      <div><label class="label">Logo URL</label><input v-model="f.logo_url" class="input" ></div>
      <div>
        <label class="label">Shop type</label>
        <select v-model="f.kind" class="input"><option value="seller">Seller — own products</option><option value="creator">Creator — promote & resell</option></select>
      </div>
      <p v-if="msg" class="text-sm text-mint-500">{{ msg }}</p>
      <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
      <button class="btn-primary">Save</button>
    </form>

    <form class="card mt-6 space-y-3 p-6" @submit.prevent="addShop">
      <div class="font-bold">Open another shop</div>
      <p class="text-sm text-muted">Run multiple brands, or a separate creator storefront, from one account.</p>
      <div class="grid gap-3 sm:grid-cols-3">
        <input v-model="n.name" required placeholder="Name" class="input" >
        <input v-model="n.slug" required pattern="[a-z0-9-]{3,40}" placeholder="url-slug" class="input" >
        <select v-model="n.kind" class="input"><option value="seller">Seller</option><option value="creator">Creator</option></select>
      </div>
      <button class="btn-ghost">Create shop</button>
    </form>
  </div>
</template>
