<script setup lang="ts">
definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shopId, shop } = useShop()
type Summary = Record<'pending' | 'approved' | 'paid' | 'void', number>
interface Earned { summary: Summary; items: { id: string; order_id: string; product_name: string; supplier_name: string; amount_cents: number; status: string; created_at: string }[] }
interface Payable { summary: Summary; items: { id: string; order_id: string; product_name: string; reseller_name: string; amount_cents: number; status: string; created_at: string }[] }
const tab = ref<'earned' | 'payable'>('earned')
const { data: earned } = await useAsyncData('comm-earned', () => api<Earned>(`/shops/${shopId.value}/commissions`), { watch: [shopId] })
const { data: payable, refresh } = await useAsyncData('comm-payable', () => api<Payable>(`/shops/${shopId.value}/commissions/payable`), { watch: [shopId] })
const cur = computed(() => shop.value?.currency ?? 'THB')
const summary = computed(() => (tab.value === 'earned' ? earned.value?.summary : payable.value?.summary))
const error = ref('')
async function pay(id: string) {
  error.value = ''
  try {
    await api(`/commissions/${id}/pay`, { method: 'POST' })
    await refresh()
  } catch (e) {
    error.value = apiError(e)
  }
}
</script>

<template>
  <div>
    <h1 class="page-title">Commissions</h1>
    <p class="text-sm text-muted">Commission is <b>pending</b> when an order is placed, <b>approved</b> when it's delivered, and <b>paid</b> once the supplier settles it. Cancelled orders are voided.</p>
    <div class="mt-5 flex rounded-full border border-line bg-white p-1 text-sm font-semibold w-fit">
      <button class="rounded-full px-4 py-1.5" :class="tab === 'earned' && 'bg-ink text-white'" @click="tab = 'earned'">I earned</button>
      <button class="rounded-full px-4 py-1.5" :class="tab === 'payable' && 'bg-ink text-white'" @click="tab = 'payable'">I owe sell-staff</button>
    </div>
    <div v-if="summary" class="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
      <StatCard label="Pending" :value="money(summary.pending, cur)" />
      <StatCard label="Approved" :value="money(summary.approved, cur)" :accent="tab === 'payable' && summary.approved > 0" :hint="tab === 'payable' ? 'Ready to pay' : 'Ready for payout'" />
      <StatCard label="Paid" :value="money(summary.paid, cur)" />
      <StatCard label="Void" :value="money(summary.void, cur)" />
    </div>
    <p v-if="error" class="mt-3 text-sm text-brand-700">{{ error }}</p>

    <div v-if="tab === 'earned'">
      <div v-if="earned?.items.length" class="card mt-5 overflow-x-auto">
        <table class="table">
          <thead><tr><th>Order</th><th>Product</th><th>Supplier</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
            <tr v-for="c in earned.items" :key="c.id">
              <td>#{{ shortId(c.order_id) }}<div class="text-xs text-muted">{{ ago(c.created_at) }}</div></td>
              <td>{{ c.product_name }}</td><td>{{ c.supplier_name }}</td>
              <td class="font-bold">{{ money(c.amount_cents, cur) }}</td>
              <td><StatusBadge :status="c.status" /></td>
            </tr>
          </tbody>
        </table>
      </div>
      <EmptyState v-else class="mt-5" title="No commission yet" text="Add products to your storefront from the resell marketplace and share your links.">
        <NuxtLink to="/dashboard/marketplace" class="btn-primary">Find products to resell</NuxtLink>
      </EmptyState>
    </div>
    <div v-else>
      <div v-if="payable?.items.length" class="card mt-5 overflow-x-auto">
        <table class="table">
          <thead><tr><th>Order</th><th>Product</th><th>Sell-staff</th><th>Amount</th><th>Status</th><th /></tr></thead>
          <tbody>
            <tr v-for="c in payable.items" :key="c.id">
              <td>#{{ shortId(c.order_id) }}<div class="text-xs text-muted">{{ ago(c.created_at) }}</div></td>
              <td>{{ c.product_name }}</td><td>{{ c.reseller_name }}</td>
              <td class="font-bold">{{ money(c.amount_cents, cur) }}</td>
              <td><StatusBadge :status="c.status" /></td>
              <td class="text-right"><button v-if="c.status === 'approved'" class="btn-primary btn-sm" @click="pay(c.id)">Mark paid</button></td>
            </tr>
          </tbody>
        </table>
      </div>
      <EmptyState v-else class="mt-5" title="Nothing owed" />
    </div>
  </div>
</template>
