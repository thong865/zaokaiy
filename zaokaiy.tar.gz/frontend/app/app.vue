<template>
  <NuxtLoadingIndicator color="#ff4d2e" />
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>
