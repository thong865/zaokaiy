use std::env;

#[derive(Clone, Debug)]
pub struct Config {
    pub database_url: String,
    pub bind_addr: String,
    pub jwt_secret: String,
    pub jwt_ttl_hours: i64,
    pub cors_origins: Vec<String>,
    /// Anthropic API key. When empty, AI endpoints fall back to built-in templates.
    pub anthropic_api_key: Option<String>,
    pub ai_model: String,
    pub anthropic_base_url: String,
}

impl Config {
    pub fn from_env() -> Self {
        let get = |k: &str, d: &str| env::var(k).unwrap_or_else(|_| d.to_string());
        Self {
            database_url: get(
                "DATABASE_URL",
                "postgres://zaokaiy:zaokaiy@localhost:5432/zaokaiy",
            ),
            bind_addr: get("BIND_ADDR", "0.0.0.0:8080"),
            jwt_secret: get("JWT_SECRET", "dev-secret-change-me"),
            jwt_ttl_hours: get("JWT_TTL_HOURS", "168").parse().unwrap_or(168),
            cors_origins: get("CORS_ORIGINS", "http://localhost:3000")
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect(),
            anthropic_api_key: env::var("ANTHROPIC_API_KEY")
                .ok()
                .filter(|k| !k.trim().is_empty()),
            ai_model: get("AI_MODEL", "claude-sonnet-5"),
            anthropic_base_url: get("ANTHROPIC_BASE_URL", "https://api.anthropic.com"),
        }
    }
}
