use axum::{
    extract::{Path, Query, State},
    Json,
};
use serde::Deserialize;
use uuid::Uuid;

use crate::{
    auth::AuthUser,
    error::{AppError, AppResult},
    models::Product,
    routes::{owned_product, owned_shop},
    AppState,
};

#[derive(Deserialize)]
pub struct CreateProduct {
    pub sku: String,
    pub name: String,
    pub description: Option<String>,
    pub price_cents: i64,
    pub images: Option<Vec<String>>,
    pub category: Option<String>,
    pub status: Option<String>,
    pub initial_stock: Option<i32>,
    pub low_stock_threshold: Option<i32>,
    pub allow_resell: Option<bool>,
    pub commission_bps: Option<i32>,
}

#[derive(Deserialize)]
pub struct UpdateProduct {
    pub name: Option<String>,
    pub description: Option<String>,
    pub price_cents: Option<i64>,
    pub images: Option<Vec<String>>,
    pub category: Option<String>,
    pub status: Option<String>,
    pub low_stock_threshold: Option<i32>,
    pub allow_resell: Option<bool>,
    pub commission_bps: Option<i32>,
}

#[derive(Deserialize)]
pub struct ListQ {
    pub status: Option<String>,
    pub q: Option<String>,
}

fn check_status(s: &Option<String>) -> AppResult<()> {
    match s.as_deref() {
        None | Some("draft" | "active" | "archived") => Ok(()),
        _ => Err(AppError::bad("status must be draft, active or archived")),
    }
}

fn check_bps(b: Option<i32>) -> AppResult<()> {
    match b {
        Some(v) if !(0..=9000).contains(&v) => {
            Err(AppError::bad("commission_bps must be 0..9000 (0-90%)"))
        }
        _ => Ok(()),
    }
}

pub async fn list_for_shop(
    State(st): State<AppState>,
    user: AuthUser,
    Path(shop_id): Path<Uuid>,
    Query(q): Query<ListQ>,
) -> AppResult<Json<Vec<Product>>> {
    owned_shop(&st, shop_id, &user).await?;
    let rows = sqlx::query_as(
        "SELECT * FROM products
         WHERE shop_id = $1
           AND ($2::text IS NULL OR status = $2)
           AND ($3::text IS NULL OR name ILIKE '%' || $3 || '%' OR sku ILIKE '%' || $3 || '%')
         ORDER BY updated_at DESC",
    )
    .bind(shop_id)
    .bind(q.status)
    .bind(q.q.filter(|s| !s.trim().is_empty()))
    .fetch_all(&st.db)
    .await?;
    Ok(Json(rows))
}

pub async fn get_owned(
    State(st): State<AppState>,
    user: AuthUser,
    Path(id): Path<Uuid>,
) -> AppResult<Json<Product>> {
    Ok(Json(owned_product(&st, id, &user).await?))
}

pub async fn create(
    State(st): State<AppState>,
    user: AuthUser,
    Path(shop_id): Path<Uuid>,
    Json(req): Json<CreateProduct>,
) -> AppResult<Json<Product>> {
    owned_shop(&st, shop_id, &user).await?;
    check_status(&req.status)?;
    check_bps(req.commission_bps)?;
    if req.name.trim().is_empty() || req.sku.trim().is_empty() {
        return Err(AppError::bad("name and sku are required"));
    }
    if req.price_cents < 0 {
        return Err(AppError::bad("price_cents must be >= 0"));
    }
    let stock = req.initial_stock.unwrap_or(0);
    if stock < 0 {
        return Err(AppError::bad("initial_stock must be >= 0"));
    }

    let mut tx = st.db.begin().await?;
    let p: Product = sqlx::query_as(
        "INSERT INTO products (shop_id, sku, name, description, price_cents, images, category, status,
                               stock, low_stock_threshold, allow_resell, commission_bps)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *",
    )
    .bind(shop_id)
    .bind(req.sku.trim())
    .bind(req.name.trim())
    .bind(req.description.unwrap_or_default())
    .bind(req.price_cents)
    .bind(serde_json::json!(req.images.unwrap_or_default()))
    .bind(req.category.unwrap_or_else(|| "general".into()))
    .bind(req.status.unwrap_or_else(|| "draft".into()))
    .bind(stock)
    .bind(req.low_stock_threshold.unwrap_or(5))
    .bind(req.allow_resell.unwrap_or(false))
    .bind(req.commission_bps.unwrap_or(1000))
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| match AppError::from(e) {
        AppError::Conflict(_) => AppError::Conflict("SKU already exists in this shop".into()),
        o => o,
    })?;
    if stock > 0 {
        sqlx::query(
            "INSERT INTO inventory_movements (product_id, delta, stock_after, reason, note, created_by)
             VALUES ($1,$2,$2,'restock','initial stock',$3)",
        )
        .bind(p.id)
        .bind(stock)
        .bind(user.id)
        .execute(&mut *tx)
        .await?;
    }
    tx.commit().await?;
    Ok(Json(p))
}

pub async fn update(
    State(st): State<AppState>,
    user: AuthUser,
    Path(id): Path<Uuid>,
    Json(req): Json<UpdateProduct>,
) -> AppResult<Json<Product>> {
    owned_product(&st, id, &user).await?;
    check_status(&req.status)?;
    check_bps(req.commission_bps)?;
    if matches!(req.price_cents, Some(p) if p < 0) {
        return Err(AppError::bad("price_cents must be >= 0"));
    }
    let p: Product = sqlx::query_as(
        "UPDATE products SET
            name = COALESCE($2, name),
            description = COALESCE($3, description),
            price_cents = COALESCE($4, price_cents),
            images = COALESCE($5, images),
            category = COALESCE($6, category),
            status = COALESCE($7, status),
            low_stock_threshold = COALESCE($8, low_stock_threshold),
            allow_resell = COALESCE($9, allow_resell),
            commission_bps = COALESCE($10, commission_bps),
            updated_at = now()
         WHERE id = $1 RETURNING *",
    )
    .bind(id)
    .bind(req.name)
    .bind(req.description)
    .bind(req.price_cents)
    .bind(req.images.map(|v| serde_json::json!(v)))
    .bind(req.category)
    .bind(req.status)
    .bind(req.low_stock_threshold)
    .bind(req.allow_resell)
    .bind(req.commission_bps)
    .fetch_one(&st.db)
    .await?;
    Ok(Json(p))
}

pub async fn archive(
    State(st): State<AppState>,
    user: AuthUser,
    Path(id): Path<Uuid>,
) -> AppResult<Json<Product>> {
    owned_product(&st, id, &user).await?;
    let p: Product = sqlx::query_as(
        "UPDATE products SET status='archived', updated_at=now() WHERE id=$1 RETURNING *",
    )
    .bind(id)
    .fetch_one(&st.db)
    .await?;
    Ok(Json(p))
}
