use axum::{
    extract::{Path, State},
    Json,
};
use serde::Deserialize;
use uuid::Uuid;

use crate::{
    auth::AuthUser,
    error::{AppError, AppResult},
    models::Shop,
    routes::owned_shop,
    AppState,
};

#[derive(Deserialize)]
pub struct CreateShop {
    pub slug: String,
    pub name: String,
    pub description: Option<String>,
    pub logo_url: Option<String>,
    pub currency: Option<String>,
    pub kind: Option<String>,
}

#[derive(Deserialize)]
pub struct UpdateShop {
    pub name: Option<String>,
    pub description: Option<String>,
    pub logo_url: Option<String>,
    pub kind: Option<String>,
}

fn valid_slug(s: &str) -> bool {
    (3..=40).contains(&s.len())
        && s.chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-')
}

fn valid_kind(k: &str) -> bool {
    matches!(k, "seller" | "creator")
}

pub async fn my_shops(State(st): State<AppState>, user: AuthUser) -> AppResult<Json<Vec<Shop>>> {
    let shops = sqlx::query_as("SELECT * FROM shops WHERE owner_id = $1 ORDER BY created_at")
        .bind(user.id)
        .fetch_all(&st.db)
        .await?;
    Ok(Json(shops))
}

pub async fn create_shop(
    State(st): State<AppState>,
    user: AuthUser,
    Json(req): Json<CreateShop>,
) -> AppResult<Json<Shop>> {
    let slug = req.slug.trim().to_lowercase();
    if !valid_slug(&slug) {
        return Err(AppError::bad("slug must be 3-40 chars: a-z, 0-9, '-'"));
    }
    if req.name.trim().is_empty() {
        return Err(AppError::bad("name is required"));
    }
    let kind = req.kind.unwrap_or_else(|| "seller".into());
    if !valid_kind(&kind) {
        return Err(AppError::bad("kind must be seller or creator"));
    }
    let shop: Shop = sqlx::query_as(
        "INSERT INTO shops (owner_id, slug, name, description, logo_url, currency, kind)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *",
    )
    .bind(user.id)
    .bind(&slug)
    .bind(req.name.trim())
    .bind(req.description.unwrap_or_default())
    .bind(req.logo_url)
    .bind(req.currency.unwrap_or_else(|| "THB".into()).to_uppercase())
    .bind(kind)
    .fetch_one(&st.db)
    .await
    .map_err(|e| match AppError::from(e) {
        AppError::Conflict(_) => AppError::Conflict("shop slug already taken".into()),
        o => o,
    })?;
    Ok(Json(shop))
}

pub async fn update_shop(
    State(st): State<AppState>,
    user: AuthUser,
    Path(id): Path<Uuid>,
    Json(req): Json<UpdateShop>,
) -> AppResult<Json<Shop>> {
    owned_shop(&st, id, &user).await?;
    if let Some(k) = &req.kind {
        if !valid_kind(k) {
            return Err(AppError::bad("kind must be seller or creator"));
        }
    }
    let shop: Shop = sqlx::query_as(
        "UPDATE shops SET
            name = COALESCE($2, name),
            description = COALESCE($3, description),
            logo_url = COALESCE($4, logo_url),
            kind = COALESCE($5, kind)
         WHERE id = $1 RETURNING *",
    )
    .bind(id)
    .bind(req.name)
    .bind(req.description)
    .bind(req.logo_url)
    .bind(req.kind)
    .fetch_one(&st.db)
    .await?;
    Ok(Json(shop))
}
