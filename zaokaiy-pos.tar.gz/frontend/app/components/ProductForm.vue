<script setup lang="ts">
import type { Product } from '~/utils/types'

const props = defineProps<{ product?: Product | null; busy?: boolean; currency?: string; autoApprove?: boolean }>()
const emit = defineEmits<{ submit: [body: Record<string, unknown>] }>()

const f = reactive({
  sku: props.product?.sku ?? '',
  name: props.product?.name ?? '',
  description: props.product?.description ?? '',
  price: props.product ? props.product.price_cents / 100 : 0,
  barcode: props.product?.barcode ?? '',
  category_id: props.product?.category_id ?? null,
  shop_category_id: props.product?.shop_category_id ?? null,
  status: props.product?.status ?? 'active',
  initial_stock: 0,
  low_stock_threshold: props.product?.low_stock_threshold ?? 5,
  allow_resell: props.product?.allow_resell ?? false,
  commission: (props.product?.commission_bps ?? 1000) / 100,
})
watch(() => props.product?.description, (d) => { if (d !== undefined) f.description = d })

function submit() {
  const body: Record<string, unknown> = {
    name: f.name,
    description: f.description,
    price_cents: Math.round(Number(f.price) * 100),
    ...(f.category_id ? { category_id: f.category_id } : {}),
    shop_category_id: f.shop_category_id || null,
    barcode: f.barcode.trim(),
    status: f.status,
    low_stock_threshold: Number(f.low_stock_threshold),
    allow_resell: f.allow_resell,
    commission_bps: Math.round(Number(f.commission) * 100),
  }
  if (!props.product) {
    body.sku = f.sku
    body.initial_stock = Number(f.initial_stock)
  }
  emit('submit', body)
}
const { data: marketCats } = await useMarketplaceCategories()
const { data: shopCats } = await useShopCategories()

// Warn before an edit sends a live product back to the review queue.
const reviewNeeded = computed(() => {
  if (props.autoApprove) return false
  if (!props.product) return f.status === 'active'
  const p = props.product
  if (f.status !== 'active') return false
  if (p.review_status === 'not_submitted' || p.review_status === 'rejected') return true
  return p.review_status === 'approved' && (f.name.trim() !== p.name || f.description !== p.description || f.category_id !== p.category_id)
})
const publishBlocked = computed(() => f.status === 'active' && !f.category_id && props.product?.review_status !== 'approved')
const submitLabel = computed(() => {
  if (props.busy) return 'Saving…'
  if (!props.product) return f.status === 'active' ? (props.autoApprove ? 'Create & publish' : 'Create & submit for review') : 'Save draft'
  return reviewNeeded.value ? 'Save & submit for review' : 'Save changes'
})
const perUnit = computed(() => Math.floor(Number(f.price) * 100 * Number(f.commission) / 100))
defineExpose({ f })
</script>

<template>
  <form class="grid gap-6 lg:grid-cols-[1fr_320px]" @submit.prevent="submit">
    <div class="card space-y-4 p-6">
      <div class="grid gap-4 sm:grid-cols-[1fr_180px]">
        <div><label class="label">Name</label><input v-model="f.name" required class="input" ></div>
        <div><label class="label">SKU</label><input v-model="f.sku" :disabled="!!product" required class="input disabled:bg-paper" ></div>
      </div>
      <div>
        <div class="flex items-center justify-between"><label class="label">Description</label><slot name="description-tools" /></div>
        <textarea v-model="f.description" rows="8" class="input" />
      </div>
      <slot name="media" />
      <div class="grid gap-4 sm:grid-cols-2">
        <div><label class="label">Price ({{ currency ?? 'THB' }})</label><input v-model="f.price" type="number" min="0" step="0.01" required class="input" ></div>
        <div>
          <label class="label">Status</label>
          <select v-model="f.status" class="input"><option value="draft">Draft — not published</option><option value="active">Active — publish</option><option value="archived">Archived</option></select>
        </div>
      </div>
    </div>
    <div class="space-y-4">
      <div class="card space-y-4 p-5">
        <div class="font-bold">Categories</div>
        <div>
          <label class="label">Marketplace category <span class="normal-case tracking-normal text-brand-600">· required to publish</span></label>
          <CategorySelect v-model="f.category_id" :nodes="marketCats" require-leaf />
        </div>
        <div>
          <div class="flex items-center justify-between">
            <label class="label">Shop category</label>
            <NuxtLink to="/dashboard/categories" class="mb-1.5 text-xs font-semibold text-brand-600 hover:underline">Manage</NuxtLink>
          </div>
          <select v-model="f.shop_category_id" class="input">
            <option :value="null">— None —</option>
            <option v-for="c in shopCats" :key="c.id" :value="c.id">{{ '\u00a0\u00a0\u00a0'.repeat(c.depth) }}{{ c.depth ? '└ ' : '' }}{{ c.name }}</option>
          </select>
          <p v-if="!shopCats.length" class="mt-1 text-xs text-muted">Organise your storefront with your own categories & sub-categories.</p>
        </div>
      </div>
      <div class="card space-y-4 p-5">
        <div class="font-bold">Inventory</div>
        <div v-if="!product"><label class="label">Initial stock</label><input v-model="f.initial_stock" type="number" min="0" class="input" ></div>
        <div v-else class="text-sm">In stock: <b>{{ product.stock }}</b> <NuxtLink to="/dashboard/inventory" class="text-brand-600 underline">adjust</NuxtLink></div>
        <div><label class="label">Barcode (for POS scanning)</label><input v-model="f.barcode" class="input font-mono" placeholder="Scan or type EAN / UPC" ></div>
        <div><label class="label">Low-stock alert at</label><input v-model="f.low_stock_threshold" type="number" min="0" class="input" ></div>
      </div>
      <div class="card space-y-4 p-5">
        <label class="flex items-center justify-between gap-3">
          <span><span class="font-bold">Open to sell-staff</span><br><span class="text-xs text-muted">Let approved shops & creators resell this.</span></span>
          <input v-model="f.allow_resell" type="checkbox" class="size-5 accent-brand-500" >
        </label>
        <div v-if="f.allow_resell">
          <label class="label">Default commission (%)</label>
          <input v-model="f.commission" type="number" min="0" max="90" step="0.5" class="input" >
          <p class="mt-1 text-xs text-muted">≈ {{ money(perUnit, currency) }} per unit. You can set a custom rate per sell-staff.</p>
        </div>
      </div>
      <button class="btn-primary w-full" :disabled="busy || publishBlocked">{{ submitLabel }}</button>
      <p v-if="publishBlocked" class="-mt-2 text-center text-xs text-brand-700">Choose a marketplace category to publish, or save as draft.</p>
      <p v-else-if="reviewNeeded && product?.review_status === 'approved'" class="-mt-2 text-center text-xs text-amber-700">These changes will be reviewed before they go live — the product is hidden until approved.</p>
      <p v-else-if="reviewNeeded" class="-mt-2 text-center text-xs text-muted">Our team reviews new listings, usually within a day.</p>
      <slot name="after" />
    </div>
  </form>
</template>
