<script setup lang="ts">
import type { Shop } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shop, shops, createShop } = useShop()
const f = reactive({ name: '', description: '', logo_url: '', kind: 'seller' })
const biz = reactive({ legal_name: '', tax_id: '', branch: '', address: '', phone: '', vat: 7, prices_include_vat: true, receipt_prefix: 'R', invoice_prefix: 'INV', receipt_footer: '' })
watch(shop, (s) => {
  if (!s) return
  Object.assign(f, { name: s.name, description: s.description, logo_url: s.logo_url ?? '', kind: s.kind })
  Object.assign(biz, { legal_name: s.legal_name, tax_id: s.tax_id, branch: s.branch, address: s.address, phone: s.phone, vat: s.vat_bps / 100,
    prices_include_vat: s.prices_include_vat, receipt_prefix: s.receipt_prefix, invoice_prefix: s.invoice_prefix, receipt_footer: s.receipt_footer })
}, { immediate: true })
const bizMsg = ref('')
async function saveBiz() {
  bizMsg.value = error.value = ''
  try {
    const { vat, ...rest } = biz
    const updated = await api<Shop>(`/shops/${shop.value!.id}`, { method: 'PATCH', body: { ...rest, vat_bps: Math.round(Number(vat) * 100) } })
    const i = shops.value.findIndex((s) => s.id === updated.id)
    shops.value[i] = updated
    bizMsg.value = 'Saved'
  } catch (e) {
    error.value = apiError(e)
  }
}
const msg = ref('')
const error = ref('')
async function save() {
  msg.value = error.value = ''
  try {
    const updated = await api<Shop>(`/shops/${shop.value!.id}`, { method: 'PATCH', body: { ...f, logo_url: f.logo_url || null } })
    const i = shops.value.findIndex((s) => s.id === updated.id)
    shops.value[i] = updated
    msg.value = 'Saved'
  } catch (e) {
    error.value = apiError(e)
  }
}
const n = reactive({ name: '', slug: '', kind: 'creator' })
async function addShop() {
  error.value = ''
  try {
    await createShop({ ...n } as never)
    Object.assign(n, { name: '', slug: '' })
  } catch (e) {
    error.value = apiError(e)
  }
}
</script>

<template>
  <div class="max-w-2xl">
    <h1 class="page-title">Shop settings</h1>
    <form class="card mt-6 space-y-4 p-6" @submit.prevent="save">
      <div><label class="label">Name</label><input v-model="f.name" required class="input" ></div>
      <div><label class="label">URL</label><input :value="`/s/${shop?.slug}`" disabled class="input bg-paper" ></div>
      <div><label class="label">About</label><textarea v-model="f.description" rows="4" class="input" /></div>
      <div><label class="label">Logo URL</label><input v-model="f.logo_url" class="input" ></div>
      <div>
        <label class="label">Shop type</label>
        <select v-model="f.kind" class="input"><option value="seller">Seller — own products</option><option value="creator">Creator — promote & resell</option></select>
      </div>
      <p v-if="msg" class="text-sm text-mint-500">{{ msg }}</p>
      <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
      <button class="btn-primary">Save</button>
    </form>

    <form class="card mt-6 space-y-4 p-6" @submit.prevent="saveBiz">
      <div>
        <div class="font-bold">Business & tax details</div>
        <p class="text-sm text-muted">Printed on POS receipts, tax invoices and order invoices.</p>
      </div>
      <div class="grid gap-3 sm:grid-cols-2">
        <div class="sm:col-span-2"><label class="label">Registered business name</label><input v-model="biz.legal_name" class="input" placeholder="e.g. Siam Crafts Co., Ltd." ></div>
        <div><label class="label">Tax ID</label><input v-model="biz.tax_id" class="input" placeholder="13 digits" inputmode="numeric" ></div>
        <div><label class="label">Branch</label><input v-model="biz.branch" class="input" placeholder="Head office / สำนักงานใหญ่" ></div>
        <div class="sm:col-span-2"><label class="label">Address</label><textarea v-model="biz.address" rows="2" class="input" /></div>
        <div><label class="label">Phone</label><input v-model="biz.phone" class="input" ></div>
        <div>
          <label class="label">VAT rate (%)</label>
          <input v-model="biz.vat" type="number" min="0" max="30" step="0.01" class="input" >
        </div>
        <label class="flex items-center gap-2 text-sm sm:col-span-2"><input v-model="biz.prices_include_vat" type="checkbox" class="size-4 accent-brand-500"> Product prices already include VAT</label>
        <div><label class="label">Receipt no. prefix</label><input v-model="biz.receipt_prefix" maxlength="8" class="input font-mono" ></div>
        <div><label class="label">Tax invoice no. prefix</label><input v-model="biz.invoice_prefix" maxlength="8" class="input font-mono" ></div>
        <div class="sm:col-span-2"><label class="label">Receipt footer</label><textarea v-model="biz.receipt_footer" rows="2" class="input" placeholder="Thank you! Exchanges within 7 days with receipt." /></div>
      </div>
      <p v-if="bizMsg" class="text-sm text-mint-500">{{ bizMsg }}</p>
      <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
      <button class="btn-primary">Save business details</button>
    </form>

    <form class="card mt-6 space-y-3 p-6" @submit.prevent="addShop">
      <div class="font-bold">Open another shop</div>
      <p class="text-sm text-muted">Run multiple brands, or a separate creator storefront, from one account.</p>
      <div class="grid gap-3 sm:grid-cols-3">
        <input v-model="n.name" required placeholder="Name" class="input" >
        <input v-model="n.slug" required pattern="[a-z0-9-]{3,40}" placeholder="url-slug" class="input" >
        <select v-model="n.kind" class="input"><option value="seller">Seller</option><option value="creator">Creator</option></select>
      </div>
      <button class="btn-ghost">Create shop</button>
    </form>
  </div>
</template>
