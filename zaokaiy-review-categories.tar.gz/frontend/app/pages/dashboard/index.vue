<script setup lang="ts">
definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shops, shop, shopId, createShop } = useShop()

interface Stats {
  revenue_cents: number
  orders: number
  units_sold: number
  orders_to_ship: number
  products: number
  active_products: number
  in_review: number
  rejected: number
  low_stock: number
  commission_earned_cents: number
  commission_owed_cents: number
  ad_spend_cents: number
  ad_clicks: number
  ad_impressions: number
  resellers: number
  pending_reseller_requests: number
  revenue_series: { date: string; revenue_cents: number }[]
  top_products: { name: string; units: number; revenue_cents: number }[]
}
const { data: stats } = await useAsyncData('stats', () => (shopId.value ? api<Stats>(`/shops/${shopId.value}/stats`) : Promise.resolve(null)), {
  watch: [shopId],
})

const form = reactive({ name: '', slug: '', kind: 'seller', description: '' })
const error = ref('')
watch(() => form.name, (n) => {
  form.slug = n.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40)
})
async function create() {
  error.value = ''
  try {
    await createShop({ ...form } as never)
  } catch (e) {
    error.value = apiError(e)
  }
}
const cur = computed(() => shop.value?.currency ?? 'THB')
const ctr = computed(() => (stats.value?.ad_impressions ? ((stats.value.ad_clicks / stats.value.ad_impressions) * 100).toFixed(1) + '%' : '—'))
</script>

<template>
  <div>
    <div v-if="!shops.length" class="mx-auto max-w-xl py-10">
      <h1 class="page-title text-3xl">Open your shop</h1>
      <p class="mt-1 text-muted">Sell your own products, resell others' as a sell-staff, or both.</p>
      <form class="card mt-8 space-y-4 p-6" @submit.prevent="create">
        <div class="grid grid-cols-2 gap-3">
          <button v-for="k in [['seller', 'Seller', 'I have my own products'], ['creator', 'Creator', 'I promote & resell products']]" :key="k[0]" type="button" class="rounded-2xl border-2 p-4 text-left" :class="form.kind === k[0] ? 'border-ink bg-paper' : 'border-line'" @click="form.kind = k[0]!">
            <div class="font-bold">{{ k[1] }}</div><div class="text-xs text-muted">{{ k[2] }}</div>
          </button>
        </div>
        <div><label class="label">Shop name</label><input v-model="form.name" required class="input" ></div>
        <div>
          <label class="label">Shop URL</label>
          <div class="flex items-center gap-2 text-sm"><span class="text-muted">zaokaiy/s/</span><input v-model="form.slug" required pattern="[a-z0-9-]{3,40}" class="input" ></div>
        </div>
        <div><label class="label">About</label><textarea v-model="form.description" rows="3" class="input" /></div>
        <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
        <button class="btn-primary w-full">Create shop</button>
      </form>
    </div>

    <div v-else-if="stats">
      <div class="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 class="page-title">Hello, {{ shop?.name }}</h1>
          <p class="text-sm text-muted">Here's how your shop is doing.</p>
        </div>
        <div class="flex gap-2">
          <NuxtLink to="/dashboard/assistant" class="btn-ghost">✦ Ask AI</NuxtLink>
          <NuxtLink to="/dashboard/products/new" class="btn-primary">+ New product</NuxtLink>
        </div>
      </div>

      <NuxtLink v-if="stats.rejected || stats.in_review" to="/dashboard/products" class="mt-6 flex flex-wrap items-center gap-3 rounded-2xl border px-4 py-3 text-sm" :class="stats.rejected ? 'border-brand-500/40 bg-brand-50' : 'border-sun-400/60 bg-sun-400/10'">
        <span v-if="stats.rejected"><b>{{ stats.rejected }}</b> product{{ stats.rejected > 1 ? 's need' : ' needs' }} changes before going live.</span>
        <span v-if="stats.in_review"><b>{{ stats.in_review }}</b> waiting for marketplace review.</span>
        <span class="ml-auto font-semibold underline">View products →</span>
      </NuxtLink>
      <div class="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Revenue" :value="money(stats.revenue_cents, cur)" :hint="`${stats.units_sold} units · ${stats.orders} orders`" accent />
        <StatCard label="To ship" :value="stats.orders_to_ship" hint="Paid orders waiting" to="/dashboard/orders" />
        <StatCard label="Low stock" :value="stats.low_stock" :hint="`${stats.active_products}/${stats.products} products live`" to="/dashboard/inventory" />
        <StatCard label="Sell-staff" :value="stats.resellers" :hint="`${stats.pending_reseller_requests} pending requests`" to="/dashboard/partners" />
      </div>

      <div class="mt-4 grid gap-4 lg:grid-cols-[2fr_1fr]">
        <div class="card p-5">
          <div class="font-bold">Revenue</div>
          <RevenueChart class="mt-3" :series="stats.revenue_series" :currency="cur" />
        </div>
        <div class="card p-5">
          <div class="font-bold">Top products</div>
          <ol v-if="stats.top_products.length" class="mt-3 space-y-3 text-sm">
            <li v-for="(t, i) in stats.top_products" :key="t.name" class="flex items-center gap-3">
              <span class="grid size-6 place-items-center rounded-full bg-paper text-xs font-bold">{{ i + 1 }}</span>
              <span class="flex-1 truncate">{{ t.name }}</span>
              <span class="font-semibold">{{ money(t.revenue_cents, cur) }}</span>
            </li>
          </ol>
          <p v-else class="mt-3 text-sm text-muted">No sales yet.</p>
        </div>
      </div>

      <div class="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Commission earned" :value="money(stats.commission_earned_cents, cur)" hint="As a sell-staff" to="/dashboard/commissions" />
        <StatCard label="Commission owed" :value="money(stats.commission_owed_cents, cur)" hint="To your sell-staff" to="/dashboard/commissions" />
        <StatCard label="Ad spend" :value="money(stats.ad_spend_cents, cur)" :hint="`${stats.ad_clicks} clicks`" to="/dashboard/ads" />
        <StatCard label="Ad CTR" :value="ctr" :hint="`${stats.ad_impressions} impressions`" to="/dashboard/ads" />
      </div>
    </div>
  </div>
</template>
