<script setup lang="ts">
definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const { shopId, shop } = useShop()
const { data: nodes, refresh } = await useShopCategories()
</script>

<template>
  <div>
    <h1 class="page-title">Shop categories</h1>
    <p class="text-sm text-muted">
      Build your own category & sub-category tree to organise
      <NuxtLink v-if="shop" :to="`/s/${shop.slug}`" target="_blank" class="font-semibold text-ink underline">your storefront</NuxtLink>.
      This is separate from the marketplace category each product needs for search and browsing.
    </p>
    <CategoryTreeManager v-if="shopId" class="mt-6" scope="shop" :shop-id="shopId" :create-path="`/shops/${shopId}/categories`" :nodes="nodes" @changed="refresh()" />
  </div>
</template>
