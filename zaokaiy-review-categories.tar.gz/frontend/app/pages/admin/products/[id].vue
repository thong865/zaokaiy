<script setup lang="ts">
import type { Product, PublicMedia, ReviewEvent, Shop } from '~/utils/types'

definePageMeta({ layout: 'admin', middleware: 'admin' })
const api = useApi()
const route = useRoute()
interface Detail {
  product: Product
  shop: Shop
  owner: { email: string; name: string }
  shop_stats: { approved: number; rejected: number }
  category_path: string | null
  media: PublicMedia[]
  history: ReviewEvent[]
}
const { data, refresh } = await useAsyncData(`admin-product:${route.params.id}`, () => api<Detail>(`/admin/products/${route.params.id}`))
if (!data.value) throw createError({ statusCode: 404, statusMessage: 'Product not found' })

const note = ref('')
const error = ref('')
const busy = ref(false)
const templates = [
  'Photos are missing, blurry or not of the actual product.',
  'Description is too short or misleading — please describe the product accurately.',
  'Wrong marketplace category — please choose the correct one.',
  'Price looks incorrect.',
  'This item is not allowed on the marketplace.',
]
async function decide(action: 'approve' | 'reject') {
  error.value = ''
  busy.value = true
  try {
    await api(`/admin/products/${route.params.id}/review`, { method: 'POST', body: { action, note: note.value } })
    note.value = ''
    await refresh()
    // jump to the next pending item, if any
    const next = await api<{ id: string }[]>('/admin/products', { query: { review_status: 'pending', limit: 1 } })
    if (next[0] && next[0].id !== route.params.id) await navigateTo(`/admin/products/${next[0].id}`)
  } catch (e) {
    error.value = apiError(e)
  } finally {
    busy.value = false
  }
}
const shortTpl = (t: string) => t.split(/ — |\./)[0] ?? t
const actionLabel: Record<string, string> = { submitted: 'Submitted', resubmitted: 'Resubmitted', approved: 'Approved', auto_approved: 'Auto-approved', rejected: 'Rejected' }
</script>

<template>
  <div v-if="data">
    <NuxtLink to="/admin" class="text-sm text-muted hover:text-ink">← Review queue</NuxtLink>
    <div class="mt-2 flex flex-wrap items-center gap-3">
      <h1 class="page-title">{{ data.product.name }}</h1>
      <StatusBadge :status="data.product.review_status" :label="reviewLabel[data.product.review_status]" />
      <StatusBadge :status="data.product.status" />
    </div>

    <div class="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
      <div class="space-y-6">
        <div class="card p-5">
          <ProductGallery v-if="data.media.length" :media="data.media" :name="data.product.name" class="mx-auto max-w-lg" />
          <p v-else class="rounded-xl bg-sun-400/15 p-4 text-sm text-amber-800">⚠ No photos or videos.</p>
        </div>
        <div class="card space-y-4 p-5">
          <dl class="grid grid-cols-2 gap-4 text-sm sm:grid-cols-4">
            <div><dt class="text-xs text-muted">Price</dt><dd class="font-bold">{{ money(data.product.price_cents, data.shop.currency) }}</dd></div>
            <div><dt class="text-xs text-muted">Stock</dt><dd class="font-bold">{{ data.product.stock }}</dd></div>
            <div><dt class="text-xs text-muted">SKU</dt><dd class="font-mono text-xs">{{ data.product.sku }}</dd></div>
            <div><dt class="text-xs text-muted">Sell-staff</dt><dd class="font-bold">{{ data.product.allow_resell ? pct(data.product.commission_bps) : 'Off' }}</dd></div>
          </dl>
          <div>
            <div class="text-xs text-muted">Marketplace category</div>
            <div class="font-semibold" :class="!data.category_path && 'text-brand-700'">{{ data.category_path ?? 'None' }}</div>
          </div>
          <div>
            <div class="text-xs text-muted">Description</div>
            <p class="mt-1 whitespace-pre-line text-sm">{{ data.product.description || '—' }}</p>
          </div>
        </div>
      </div>

      <div class="space-y-4">
        <div class="card sticky top-20 space-y-3 p-5">
          <div class="font-bold">Decision</div>
          <textarea v-model="note" rows="3" class="input" placeholder="Note to seller (required to reject)" />
          <div class="flex flex-wrap gap-1.5">
            <button v-for="t in templates" :key="t" type="button" class="chip border border-line bg-white px-2 py-1 text-left font-medium hover:border-ink" @click="note = t">{{ shortTpl(t) }}</button>
          </div>
          <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
          <div class="grid grid-cols-2 gap-2">
            <button class="btn bg-brand-50 text-brand-700 hover:bg-brand-100" :disabled="busy || !note.trim()" @click="decide('reject')">Request changes</button>
            <button class="btn-primary" :disabled="busy" @click="decide('approve')">Approve</button>
          </div>
          <p class="text-xs text-muted">Approving an item that's already live keeps it live; rejecting takes it down until the seller fixes it.</p>
        </div>
        <div class="card space-y-2 p-5 text-sm">
          <div class="font-bold">Seller</div>
          <NuxtLink :to="`/s/${data.shop.slug}`" target="_blank" class="font-semibold hover:underline">{{ data.shop.name }} ↗</NuxtLink>
          <div class="text-muted">{{ data.owner.name }} · {{ data.owner.email }}</div>
          <div class="text-muted">Joined {{ new Date(data.shop.created_at).toLocaleDateString() }} · {{ data.shop_stats.approved }} approved · {{ data.shop_stats.rejected }} rejected</div>
          <span v-if="data.shop.auto_approve" class="chip bg-mint-500/15 text-mint-500">Trusted — auto-approve</span>
        </div>
        <div class="card p-5 text-sm">
          <div class="font-bold">History</div>
          <ol class="mt-2 space-y-2">
            <li v-for="(h, i) in data.history" :key="i">
              <b>{{ actionLabel[h.action] }}</b> <span class="text-muted">· {{ h.actor ?? 'system' }} · {{ ago(h.created_at) }}</span>
              <div v-if="h.note" class="text-muted">“{{ h.note }}”</div>
            </li>
            <li v-if="!data.history.length" class="text-muted">No activity.</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</template>
