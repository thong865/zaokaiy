<script setup lang="ts">
import type { CategoryNode } from '~/utils/types'

definePageMeta({ layout: 'admin', middleware: 'admin' })
const api = useApi()
const { data: nodes, refresh } = await useAsyncData('admin-categories', () => api<CategoryNode[]>('/admin/categories'), { default: () => [] })
async function changed() {
  await refresh()
  clearNuxtData('marketplace-categories')
}
</script>

<template>
  <div class="max-w-4xl">
    <h1 class="page-title">Marketplace categories</h1>
    <p class="text-sm text-muted">The shared taxonomy every seller picks from and shoppers browse. Hide a category to stop new products using it without affecting existing ones.</p>
    <CategoryTreeManager class="mt-6" scope="marketplace" create-path="/admin/categories" :nodes="nodes" @changed="changed" />
  </div>
</template>
