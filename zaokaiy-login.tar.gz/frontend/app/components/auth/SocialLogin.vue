<script setup lang="ts">
import type { AuthProviders, SessionResponse } from '~/utils/types'

/** "Continue with Google / Facebook / WhatsApp" — only the methods the server has enabled. */
const props = withDefaults(defineProps<{ redirect?: string; askName?: boolean }>(), { redirect: '/dashboard', askName: false })
const { t } = useI18n()
const api = useApi()
const { startOAuth } = useAuth()
const { data: providers } = await useAsyncData('auth-providers', () => api<AuthProviders>('/auth/providers'), {
  default: () => ({ password: true, google: false, facebook: false, whatsapp: false }),
})
const any = computed(() => providers.value.google || providers.value.facebook || providers.value.whatsapp)
const whatsapp = ref(false)
const busy = ref<string | null>(null)
const error = ref('')

async function go(p: 'google' | 'facebook') {
  error.value = ''
  busy.value = p
  try {
    await startOAuth(p, { redirect: props.redirect })
  } catch (e) {
    error.value = apiError(e)
    busy.value = null
  }
}
async function done(r: SessionResponse) {
  await navigateTo(props.redirect)
  return r
}
</script>

<template>
  <div v-if="any" class="space-y-3">
    <template v-if="!whatsapp">
      <button v-if="providers.google" type="button" class="btn-social" :disabled="!!busy" @click="go('google')">
        <span class="badge-social bg-[#4285F4]" aria-hidden="true">G</span>
        {{ busy === 'google' ? t('auth.social.redirecting') : t('auth.social.google') }}
      </button>
      <button v-if="providers.facebook" type="button" class="btn-social" :disabled="!!busy" @click="go('facebook')">
        <span class="badge-social bg-[#1877F2]" aria-hidden="true">f</span>
        {{ busy === 'facebook' ? t('auth.social.redirecting') : t('auth.social.facebook') }}
      </button>
      <button v-if="providers.whatsapp" type="button" class="btn-social" :disabled="!!busy" @click="whatsapp = true">
        <span class="badge-social bg-[#25D366]" aria-hidden="true">W</span>
        {{ t('auth.social.whatsapp') }}
      </button>
      <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
    </template>
    <AuthWhatsAppLogin v-else :ask-name="askName" @done="done" @cancel="whatsapp = false" />
    <div class="flex items-center gap-3 pt-1 text-xs font-semibold uppercase tracking-wide text-muted">
      <span class="h-px flex-1 bg-line" />{{ t('auth.social.or') }}<span class="h-px flex-1 bg-line" />
    </div>
  </div>
</template>

<style scoped>
.btn-social {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  gap: 0.6rem;
  border-radius: 9999px;
  border: 1px solid var(--color-line, #e7e2da);
  background: #fff;
  padding: 0.7rem 1rem;
  font-weight: 700;
  font-size: 0.925rem;
  transition: background 0.15s, border-color 0.15s;
}
.btn-social:hover:not(:disabled) {
  background: var(--color-paper, #faf8f5);
  border-color: #cfc8bd;
}
.btn-social:disabled {
  opacity: 0.6;
}
.badge-social {
  display: grid;
  place-items: center;
  width: 1.4rem;
  height: 1.4rem;
  border-radius: 9999px;
  color: #fff;
  font-size: 0.8rem;
  font-weight: 800;
  line-height: 1;
}
</style>
