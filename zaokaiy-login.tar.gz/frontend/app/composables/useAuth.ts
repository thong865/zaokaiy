import type { LoginProvider, SessionResponse, User } from '~/utils/types'

export function useAuth() {
  const token = useCookie<string | null>('zk_token', { maxAge: 60 * 60 * 24 * 7, sameSite: 'lax' })
  const user = useState<User | null>('auth:user', () => null)
  const api = useApi()

  const loggedIn = computed(() => !!token.value)

  async function fetchMe() {
    if (!token.value) {
      user.value = null
      return null
    }
    try {
      user.value = await api<User>('/auth/me')
    } catch {
      user.value = null
    }
    return user.value
  }

  function setSession(r: { token: string; user: User }) {
    token.value = r.token
    user.value = r.user
  }

  /** `id` is an e-mail or a phone number in international format (+856…). */
  async function login(id: string, password: string) {
    setSession(await api<{ token: string; user: User }>('/auth/login', { method: 'POST', body: { email: id, password } }))
  }

  async function register(email: string, password: string, display_name: string) {
    setSession(await api<{ token: string; user: User }>('/auth/register', { method: 'POST', body: { email, password, display_name } }))
  }

  /**
   * Google / Facebook: ask the API for the provider URL and leave the site. The provider sends the
   * browser back to /auth/callback. `link` connects the provider to the signed-in account instead.
   */
  async function startOAuth(provider: Exclude<LoginProvider, 'whatsapp'>, opts: { redirect?: string; link?: boolean } = {}) {
    const r = await api<{ url: string }>(`/auth/oauth/${provider}/start`, { method: 'POST', body: { redirect: opts.redirect || '/dashboard', link: !!opts.link } })
    if (import.meta.client) window.location.assign(r.url)
  }

  /** One-time code from /auth/callback → session. */
  async function exchange(code: string) {
    const r = await api<SessionResponse>('/auth/exchange', { method: 'POST', body: { code } })
    setSession(r)
    return r
  }

  async function whatsappSend(phone: string, lang: string) {
    return api<{ sent: boolean; phone: string; expires_in: number; resend_in: number; dev_code?: string }>('/auth/whatsapp/send', { method: 'POST', body: { phone, lang } })
  }

  async function whatsappVerify(phone: string, code: string, opts: { display_name?: string; link?: boolean } = {}) {
    const r = await api<SessionResponse>('/auth/whatsapp/verify', { method: 'POST', body: { phone, code, display_name: opts.display_name || undefined, link: !!opts.link } })
    setSession(r)
    return r
  }

  function logout() {
    token.value = null
    user.value = null
    useCookie('zk_shop').value = null
    navigateTo('/')
  }

  return { token, user, loggedIn, fetchMe, setSession, login, register, startOAuth, exchange, whatsappSend, whatsappVerify, logout }
}
