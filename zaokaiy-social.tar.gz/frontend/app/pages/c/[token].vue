<script setup lang="ts">
import type { SocialOrderDoc } from '~/utils/types'

/** Customer checkout for a comment/chat order — opened from the link in the auto-reply. No account needed. */
const route = useRoute()
const api = useApi()
const token = String(route.params.token)
const { data: doc, error: loadError } = await useAsyncData(`co:${token}`, () => api<SocialOrderDoc>(`/public/social-orders/${token}`))
if (loadError.value || !doc.value) throw createError({ statusCode: 404, statusMessage: 'Order not found', fatal: true })
useHead({ title: () => `Order ${doc.value?.order.number} · ${doc.value?.shop.name}`, meta: [{ name: 'robots', content: 'noindex' }] })

const o = computed(() => doc.value!.order)
const cur = computed(() => o.value.currency)
const f = reactive({ name: o.value.ship_name, phone: o.value.ship_phone, address: o.value.ship_address, note: o.value.customer_note })
const pay = reactive({ method: 'transfer', reference: o.value.payment_ref })
const busy = ref(false)
const error = ref('')
const editing = ref(o.value.status === 'open')
async function confirm() {
  busy.value = true
  error.value = ''
  try {
    doc.value = await api<SocialOrderDoc>(`/public/social-orders/${token}/confirm`, { method: 'POST', body: f })
    editing.value = false
  } catch (e) {
    error.value = apiError(e)
  } finally {
    busy.value = false
  }
}
async function sendPayment() {
  busy.value = true
  error.value = ''
  try {
    doc.value = await api<SocialOrderDoc>(`/public/social-orders/${token}/payment`, { method: 'POST', body: pay })
  } catch (e) {
    error.value = apiError(e)
  } finally {
    busy.value = false
  }
}
const statusText: Record<string, string> = {
  open: 'Please confirm your delivery details',
  confirmed: 'Details confirmed — waiting for payment',
  paid: 'Payment received — we’re packing your order',
  shipped: 'Shipped!',
  completed: 'Delivered — thank you!',
  cancelled: 'This order was cancelled',
  expired: 'This reservation has expired',
}
const remaining = computed(() => {
  const ms = new Date(o.value.expires_at).getTime() - Date.now()
  if (ms <= 0) return ''
  const h = Math.floor(ms / 3_600_000)
  const m = Math.floor((ms % 3_600_000) / 60_000)
  return h ? `${h} h ${m} min` : `${m} min`
})
</script>

<template>
  <div v-if="doc" class="mx-auto max-w-xl px-4 py-8">
    <div class="flex items-center gap-3">
      <ProductThumb :src="doc.shop.logo_url" :name="doc.shop.name" class="size-12" rounded="rounded-2xl" />
      <div>
        <div class="text-lg font-extrabold">{{ doc.shop.name }}</div>
        <div class="text-sm text-muted">Order <span class="font-mono font-bold text-ink">{{ o.number }}</span> · via <span class="capitalize">{{ doc.customer.provider }}</span></div>
      </div>
    </div>

    <div class="mt-5 rounded-2xl px-4 py-3 text-sm font-semibold" :class="['cancelled', 'expired'].includes(o.status) ? 'bg-brand-50 text-brand-700' : ['paid', 'shipped', 'completed'].includes(o.status) ? 'bg-mint-500/10 text-mint-500' : 'bg-sun-400/15 text-amber-800'">
      {{ statusText[o.status] }}
      <ClientOnly><span v-if="['open', 'confirmed'].includes(o.status) && remaining" class="block text-xs font-normal">Items are reserved for you for another {{ remaining }}.</span></ClientOnly>
      <span v-if="o.status === 'shipped' && o.tracking_no" class="block font-mono text-xs">Tracking: {{ o.tracking_no }}</span>
    </div>

    <div class="card mt-5 overflow-hidden">
      <ul class="divide-y divide-line/70">
        <li v-for="it in doc.items" :key="it.id" class="flex items-center gap-3 p-4">
          <span class="rounded-lg bg-ink px-2 py-1 font-mono text-xs font-bold text-white">{{ it.code }}</span>
          <div class="min-w-0 flex-1"><div class="truncate font-semibold">{{ it.name }}</div><div class="text-xs text-muted">{{ it.qty }} × {{ money(it.unit_price_cents, cur) }}</div></div>
          <div class="font-bold tabular-nums">{{ money(it.qty * it.unit_price_cents, cur) }}</div>
        </li>
      </ul>
      <dl class="space-y-1 border-t border-line bg-paper p-4 text-sm">
        <div class="flex justify-between"><dt>Subtotal</dt><dd class="tabular-nums">{{ money(o.subtotal_cents, cur) }}</dd></div>
        <div class="flex justify-between"><dt>Shipping</dt><dd class="tabular-nums">{{ o.shipping_cents ? money(o.shipping_cents, cur) : 'Free' }}</dd></div>
        <div class="flex justify-between text-lg font-extrabold"><dt>Total</dt><dd class="tabular-nums">{{ money(o.total_cents, cur) }}</dd></div>
      </dl>
    </div>

    <template v-if="['open', 'confirmed'].includes(o.status)">
      <form v-if="editing" class="card mt-5 space-y-3 p-5" @submit.prevent="confirm">
        <div class="font-bold">Delivery details</div>
        <input v-model="f.name" required class="input" placeholder="Full name" autocomplete="name" >
        <input v-model="f.phone" required class="input" placeholder="Phone number" inputmode="tel" autocomplete="tel" >
        <textarea v-model="f.address" required rows="3" class="input" placeholder="Address, district, province, postcode" autocomplete="street-address" />
        <input v-model="f.note" class="input" placeholder="Note for the shop (optional)" >
        <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
        <button class="btn-primary w-full py-3" :disabled="busy">Confirm order</button>
      </form>
      <div v-else class="card mt-5 p-5 text-sm">
        <div class="flex items-center justify-between"><div class="font-bold">Deliver to</div><button class="text-xs font-semibold text-brand-600 underline" @click="editing = true">Edit</button></div>
        <div class="mt-1 font-semibold">{{ o.ship_name }} · {{ o.ship_phone }}</div>
        <div class="whitespace-pre-line text-ink/80">{{ o.ship_address }}</div>
      </div>

      <div v-if="o.status === 'confirmed'" class="card mt-5 space-y-3 p-5">
        <div class="font-bold">Payment</div>
        <div v-if="doc.shop.payment_instructions" class="whitespace-pre-line rounded-xl bg-paper p-3 text-sm">{{ doc.shop.payment_instructions }}</div>
        <p v-else class="text-sm text-muted">The shop will contact you with payment details.</p>
        <form class="space-y-2" @submit.prevent="sendPayment">
          <div class="flex gap-2">
            <select v-model="pay.method" class="input w-36"><option value="transfer">Bank transfer</option><option value="promptpay">PromptPay</option><option value="cod">Cash on delivery</option></select>
            <input v-model="pay.reference" class="input" :placeholder="pay.method === 'cod' ? 'Type COD' : 'Transfer ref / time / last 4 digits'" >
          </div>
          <p v-if="error && !editing" class="text-sm text-brand-700">{{ error }}</p>
          <button class="btn-dark w-full" :disabled="busy">{{ o.payment_ref ? 'Update payment info' : 'I’ve paid' }}</button>
          <p v-if="o.payment_ref" class="text-center text-xs text-mint-500">Thanks! The shop will verify your payment ({{ o.payment_ref }}).</p>
        </form>
      </div>
    </template>
    <p class="mt-8 text-center text-xs text-muted">Powered by zaokaiy · <NuxtLink :to="`/s/${doc.shop.slug}`" class="underline">Visit {{ doc.shop.name }}</NuxtLink></p>
  </div>
</template>
