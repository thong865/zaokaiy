<script setup lang="ts">
import type { SocialProvider } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const config = useRuntimeConfig()
const { shopId } = useShop()
interface Ch { id: string; provider: SocialProvider; name: string; external_id: string; secret: string; active: boolean; auto_reply: boolean; has_token: boolean; last_event_at: string | null; created_at: string }
interface Settings { meta_webhook_configured: boolean; meta_signature_check: boolean; tiktok_signature_check: boolean }
const { data: channels, refresh } = await useAsyncData('social-channels', () => api<Ch[]>(`/shops/${shopId.value}/social/channels`), { watch: [shopId], default: () => [] })
const { data: settings } = await useAsyncData('social-settings-flags', () => api<Settings>(`/shops/${shopId.value}/social/settings`), { watch: [shopId] })

const apiBase = computed(() => (import.meta.client ? new URL(config.public.apiBase, location.origin).href : config.public.apiBase).replace(/\/$/, ''))
const hooks = computed(() => ({ meta: `${apiBase.value}/webhooks/meta`, tiktok: `${apiBase.value}/webhooks/tiktok` }))

const guides: Record<SocialProvider, { title: string; idLabel: string; idHelp: string; tokenHelp: string; steps: string[] }> = {
  facebook: {
    title: 'Facebook Page (posts, lives & Messenger)',
    idLabel: 'Page ID',
    idHelp: 'Facebook → your Page → About → Page transparency → Page ID',
    tokenHelp: 'Page access token with pages_manage_engagement, pages_read_user_content and pages_messaging',
    steps: [
      'Create a Meta app (developers.facebook.com) and add the Webhooks + Messenger products.',
      'Webhooks → Page: callback URL below, verify token = META_VERIFY_TOKEN from the API .env. Subscribe to “feed” and “messages”.',
      'Set META_APP_SECRET in the API .env so every webhook is signature-checked.',
      'Paste the Page ID and a long-lived Page access token here.',
    ],
  },
  whatsapp: {
    title: 'WhatsApp Business (Cloud API)',
    idLabel: 'Phone number ID',
    idHelp: 'WhatsApp Manager → API setup → Phone number ID (not the phone number itself)',
    tokenHelp: 'System-user access token with whatsapp_business_messaging',
    steps: [
      'In your Meta app add the WhatsApp product and connect your business number.',
      'Webhooks → WhatsApp Business Account: same callback URL and verify token as Facebook. Subscribe to “messages”.',
      'Paste the Phone number ID and a permanent system-user token here.',
      'Customers message your WhatsApp number, e.g. “สั่ง A01 2”. Replies go out as WhatsApp messages (within the 24-hour service window).',
    ],
  },
  tiktok: {
    title: 'TikTok (LIVE / video comments)',
    idLabel: 'Account open_id',
    idHelp: 'Your TikTok account open_id from the TikTok developer portal',
    tokenHelp: 'Not needed — TikTok has no public API for replying to LIVE comments',
    steps: [
      'TikTok only exposes LIVE comments to approved partners (TikTok Shop / LIVE partner programmes). If you have access, point its webhook at the TikTok URL below and set TIKTOK_CLIENT_SECRET.',
      'Otherwise use a comment relay tool (or an n8n workflow) that forwards comments to a “Webhook” channel — see below.',
      'Customers see their checkout link when you read it on stream or pin it; replies can’t be posted automatically.',
    ],
  },
  webhook: {
    title: 'Webhook (n8n, Make, Zapier, LINE bot, custom)',
    idLabel: '',
    idHelp: '',
    tokenHelp: '',
    steps: [
      'POST JSON to the ingest URL with an HMAC-SHA256 signature of the raw body using this channel’s secret.',
      'The response contains reply_text and checkout_url — post them back to the customer from your workflow.',
    ],
  },
}
const adding = ref<SocialProvider | null>(null)
const form = reactive({ name: '', external_id: '', access_token: '' })
const error = ref('')
async function add() {
  error.value = ''
  try {
    await api(`/shops/${shopId.value}/social/channels`, { method: 'POST', body: { provider: adding.value, ...form } })
    adding.value = null
    Object.assign(form, { name: '', external_id: '', access_token: '' })
    await refresh()
  } catch (e) {
    error.value = apiError(e)
  }
}
async function patch(c: Ch, body: Record<string, unknown>) {
  error.value = ''
  try {
    await api(`/social/channels/${c.id}`, { method: 'PATCH', body })
    await refresh()
  } catch (e) {
    error.value = apiError(e)
  }
}
async function remove(c: Ch) {
  if (!window.confirm(`Disconnect ${c.name}?`)) return
  await api(`/social/channels/${c.id}`, { method: 'DELETE' })
  await refresh()
}
const tokenEdit = reactive<Record<string, string>>({})
const copiedKey = ref('')
async function copy(text: string, key: string) {
  await navigator.clipboard?.writeText(text)
  copiedKey.value = key
  setTimeout(() => (copiedKey.value = ''), 1500)
}
const curl = (c: Ch) => `BODY='{"id":"msg-123","user_id":"line:U123","user_name":"Nok","message":"CF A01 x2"}'
SIG=$(printf '%s' "$BODY" | openssl dgst -sha256 -hmac '${c.secret}' | sed 's/^.* //')
curl -X POST ${apiBase.value}/webhooks/ingest/${c.id} \\
  -H "Content-Type: application/json" -H "X-Zaokaiy-Signature: sha256=$SIG" -d "$BODY"`
</script>

<template>
  <div>
    <h1 class="page-title">Social selling</h1>
    <SocialNav class="mt-5" />

    <div v-if="settings && (!settings.meta_webhook_configured || !settings.meta_signature_check)" class="mb-5 rounded-2xl border border-sun-400/60 bg-sun-400/10 px-4 py-3 text-sm">
      <b>Server setup:</b>
      <span v-if="!settings.meta_webhook_configured"> set <code class="rounded bg-white px-1">META_VERIFY_TOKEN</code> in the API .env to enable Facebook/WhatsApp webhooks.</span>
      <span v-if="!settings.meta_signature_check"> Set <code class="rounded bg-white px-1">META_APP_SECRET</code> so webhook signatures are verified.</span>
      <span> Webhooks must reach your API over public HTTPS (e.g. a domain or a tunnel like Cloudflare Tunnel / ngrok while testing).</span>
    </div>
    <p v-if="error" class="mb-3 text-sm text-brand-700">{{ error }}</p>

    <div v-if="channels.length" class="space-y-3">
      <div v-for="c in channels" :key="c.id" class="card p-5">
        <div class="flex flex-wrap items-center gap-3">
          <SocialProviderBadge :provider="c.provider" size="md" />
          <div>
            <div class="font-bold">{{ c.name }}</div>
            <div class="text-xs text-muted">{{ guides[c.provider].title }}<template v-if="c.external_id"> · {{ c.external_id }}</template> · {{ c.last_event_at ? `last event ${ago(c.last_event_at)}` : 'no events yet' }}</div>
          </div>
          <div class="ml-auto flex flex-wrap items-center gap-3 text-sm">
            <label v-if="c.provider !== 'tiktok' && c.provider !== 'webhook'" class="flex items-center gap-1.5"><input type="checkbox" class="accent-brand-500" :checked="c.auto_reply" @change="patch(c, { auto_reply: ($event.target as HTMLInputElement).checked })"> Auto-reply</label>
            <label class="flex items-center gap-1.5"><input type="checkbox" class="accent-brand-500" :checked="c.active" @change="patch(c, { active: ($event.target as HTMLInputElement).checked })"> Active</label>
            <button class="btn-ghost btn-sm text-brand-700" @click="remove(c)">Disconnect</button>
          </div>
        </div>
        <div class="mt-4 grid gap-3 text-sm md:grid-cols-2">
          <div v-if="c.provider === 'facebook' || c.provider === 'whatsapp'">
            <label class="label">Access token</label>
            <div class="flex gap-2">
              <input v-model="tokenEdit[c.id]" type="password" class="input py-2" :placeholder="c.has_token ? '•••••••• saved — paste to replace' : 'Paste access token'" >
              <button class="btn-ghost btn-sm" :disabled="!tokenEdit[c.id]" @click="patch(c, { access_token: tokenEdit[c.id] }); tokenEdit[c.id] = ''">Save</button>
            </div>
          </div>
          <div v-if="c.provider !== 'webhook'">
            <label class="label">Webhook callback URL</label>
            <div class="flex gap-2"><input :value="c.provider === 'tiktok' ? hooks.tiktok : hooks.meta" readonly class="input bg-paper py-2 font-mono text-xs" ><button class="btn-ghost btn-sm" @click="copy(c.provider === 'tiktok' ? hooks.tiktok : hooks.meta, c.id + 'u')">{{ copiedKey === c.id + 'u' ? '✓' : 'Copy' }}</button></div>
          </div>
          <template v-if="c.provider === 'webhook' || c.provider === 'tiktok'">
            <div>
              <label class="label">Ingest URL (signed)</label>
              <div class="flex gap-2"><input :value="`${apiBase}/webhooks/ingest/${c.id}`" readonly class="input bg-paper py-2 font-mono text-xs" ><button class="btn-ghost btn-sm" @click="copy(`${apiBase}/webhooks/ingest/${c.id}`, c.id + 'i')">{{ copiedKey === c.id + 'i' ? '✓' : 'Copy' }}</button></div>
            </div>
            <div>
              <label class="label">Signing secret</label>
              <div class="flex gap-2"><input :value="c.secret" readonly class="input bg-paper py-2 font-mono text-xs" ><button class="btn-ghost btn-sm" @click="copy(c.secret, c.id + 's')">{{ copiedKey === c.id + 's' ? '✓' : 'Copy' }}</button><button class="btn-ghost btn-sm" @click="patch(c, { rotate_secret: true })">Rotate</button></div>
            </div>
            <details class="md:col-span-2">
              <summary class="cursor-pointer text-xs font-semibold text-muted">Example request (curl)</summary>
              <pre class="mt-2 overflow-x-auto rounded-xl bg-ink p-3 text-[11px] text-white">{{ curl(c) }}</pre>
            </details>
          </template>
        </div>
      </div>
    </div>

    <h2 class="mb-3 mt-8 font-bold">Connect a channel</h2>
    <div class="grid gap-3 md:grid-cols-2">
      <div v-for="(g, p) in guides" :key="p" class="card p-5" :class="adding === p && 'border-ink'">
        <div class="flex items-center gap-3">
          <SocialProviderBadge :provider="p" size="md" />
          <div class="font-bold">{{ g.title }}</div>
          <button v-if="adding !== p" class="btn-ghost btn-sm ml-auto" @click="adding = p">Connect</button>
        </div>
        <ol class="mt-3 list-decimal space-y-1 pl-5 text-xs text-muted">
          <li v-for="(s, i) in g.steps" :key="i">{{ s }}</li>
        </ol>
        <div v-if="p !== 'webhook'" class="mt-3 flex gap-2 text-xs">
          <input :value="p === 'tiktok' ? hooks.tiktok : hooks.meta" readonly class="input bg-paper py-1.5 font-mono text-[11px]" >
          <button class="btn-ghost btn-sm" @click="copy(p === 'tiktok' ? hooks.tiktok : hooks.meta, 'g' + p)">{{ copiedKey === 'g' + p ? '✓' : 'Copy' }}</button>
        </div>
        <form v-if="adding === p" class="mt-4 space-y-2 border-t border-line pt-4" @submit.prevent="add">
          <input v-model="form.name" class="input py-2" :placeholder="`Name, e.g. ${p === 'whatsapp' ? 'Shop WhatsApp' : p === 'webhook' ? 'n8n LINE bot' : 'Main page'}`" >
          <template v-if="g.idLabel">
            <input v-model="form.external_id" required class="input py-2 font-mono" :placeholder="g.idLabel" >
            <p class="text-[11px] text-muted">{{ g.idHelp }}</p>
          </template>
          <template v-if="p === 'facebook' || p === 'whatsapp'">
            <input v-model="form.access_token" type="password" class="input py-2" placeholder="Access token" >
            <p class="text-[11px] text-muted">{{ g.tokenHelp }}. Stored on the server and never shown again.</p>
          </template>
          <div class="flex justify-end gap-2">
            <button type="button" class="btn-ghost btn-sm" @click="adding = null">Cancel</button>
            <button class="btn-primary btn-sm">Connect</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
