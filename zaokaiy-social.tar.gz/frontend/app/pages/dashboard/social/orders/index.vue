<script setup lang="ts">
definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const route = useRoute()
const { shopId, shop } = useShop()
const cur = computed(() => shop.value?.currency ?? 'THB')
interface Row { id: string; number: string; status: string; total_cents: number; customer_name: string; provider: string; has_address: boolean; expires_at: string; created_at: string; payment_ref: string; units: number; items: string }
const status = ref('')
const q = ref((route.query.q as string) || '')
const qd = ref(q.value)
let t: ReturnType<typeof setTimeout> | undefined
watch(q, (v) => { clearTimeout(t); t = setTimeout(() => (qd.value = v), 250) })
const { data: rows } = await useAsyncData(
  'social-orders',
  () => api<Row[]>(`/shops/${shopId.value}/social/orders`, { query: { status: status.value || undefined, q: qd.value || undefined } }),
  { watch: [shopId, status, qd], default: () => [] },
)
const tabs = [
  ['', 'All'],
  ['open', 'Waiting for customer'],
  ['confirmed', 'To verify payment'],
  ['paid', 'To ship'],
  ['shipped', 'Shipped'],
  ['completed', 'Completed'],
  ['expired', 'Expired'],
  ['cancelled', 'Cancelled'],
] as const
const hint = (r: Row) => {
  if (r.status === 'open') return `Waiting for checkout · reserved until ${new Date(r.expires_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}`
  if (r.status === 'confirmed') return r.payment_ref ? `Customer says paid · ref ${r.payment_ref}` : 'Address confirmed, awaiting payment'
  return ''
}
</script>

<template>
  <div>
    <h1 class="page-title">Social selling</h1>
    <SocialNav class="mt-5" />
    <div class="flex flex-wrap items-center gap-3">
      <div class="flex max-w-full gap-1 overflow-x-auto rounded-full border border-line bg-white p-1 text-sm font-semibold">
        <button v-for="t in tabs" :key="t[0]" class="whitespace-nowrap rounded-full px-3 py-1" :class="status === t[0] && 'bg-ink text-white'" @click="status = t[0]">{{ t[1] }}</button>
      </div>
      <input v-model="q" class="input w-56 py-2" placeholder="Order no., name or phone" >
    </div>
    <div v-if="rows.length" class="card mt-5 overflow-x-auto">
      <table class="table">
        <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Created</th></tr></thead>
        <tbody>
          <tr v-for="r in rows" :key="r.id" class="cursor-pointer hover:bg-paper" @click="navigateTo(`/dashboard/social/orders/${r.id}`)">
            <td class="font-mono font-bold">{{ r.number }}</td>
            <td><div class="flex items-center gap-2"><SocialProviderBadge :provider="r.provider" />{{ r.customer_name || '—' }}</div></td>
            <td class="max-w-64 truncate font-mono text-xs">{{ r.items }}</td>
            <td class="font-bold tabular-nums">{{ money(r.total_cents, cur) }}</td>
            <td>
              <StatusBadge :status="r.status" />
              <div v-if="hint(r)" class="mt-0.5 max-w-56 truncate text-[11px] text-muted">{{ hint(r) }}</div>
            </td>
            <td class="whitespace-nowrap text-muted">{{ ago(r.created_at) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <EmptyState v-else class="mt-5" title="No social orders" text="Orders appear here when customers comment product codes." >
      <NuxtLink to="/dashboard/social" class="btn-primary">Open live board</NuxtLink>
    </EmptyState>
  </div>
</template>
