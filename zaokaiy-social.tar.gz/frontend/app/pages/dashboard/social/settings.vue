<script setup lang="ts">
definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shopId, shop } = useShop()
interface S { triggers: string[]; require_trigger: boolean; hold_hours: number; max_qty: number; shipping_cents: number; reply_template: string; soldout_template: string; payment_instructions: string }
const f = reactive({ triggers: [] as string[], require_trigger: false, hold_hours: 24, max_qty: 10, shipping: 0, reply_template: '', soldout_template: '', payment_instructions: '' })
const { data } = await useAsyncData('social-settings', () => api<S>(`/shops/${shopId.value}/social/settings`), { watch: [shopId] })
watch(data, (d) => d && Object.assign(f, { ...d, shipping: d.shipping_cents / 100 }), { immediate: true })
const newTrigger = ref('')
function addTrigger() {
  const t = newTrigger.value.trim().toLowerCase()
  if (t && !f.triggers.includes(t)) f.triggers.push(t)
  newTrigger.value = ''
}
const msg = ref('')
const error = ref('')
async function save() {
  msg.value = error.value = ''
  try {
    const { shipping, ...rest } = f
    await api(`/shops/${shopId.value}/social/settings`, { method: 'PATCH', body: { ...rest, shipping_cents: Math.round(Number(shipping) * 100) } })
    msg.value = 'Saved'
  } catch (e) {
    error.value = apiError(e)
  }
}
const cur = computed(() => shop.value?.currency ?? 'THB')
const fill = (t: string) =>
  t.replaceAll('{name}', 'Nok').replaceAll('{items}', 'A01 Silk dress x2').replaceAll('{total}', money(64800, cur.value))
    .replaceAll('{link}', 'https://yourshop/c/…').replaceAll('{hours}', String(f.hold_hours)).replaceAll('{order}', 'SO000123')
const examples = ['CF A01', 'cf a01 x2', 'A01 2', 'CFA01', 'F A01=3', 'เอา A01 2 ชิ้น', 'CF A01 x2, B03']
</script>

<template>
  <div class="max-w-3xl">
    <h1 class="page-title">Social selling</h1>
    <SocialNav class="mt-5" />
    <form class="space-y-6" @submit.prevent="save">
      <div class="card space-y-4 p-6">
        <div class="font-bold">How comments are read</div>
        <div>
          <label class="label">Trigger words</label>
          <div class="flex flex-wrap items-center gap-2">
            <span v-for="(t, i) in f.triggers" :key="t" class="chip border border-line bg-paper px-2.5 py-1 font-mono text-xs">{{ t }} <button type="button" class="ml-1 text-muted hover:text-brand-700" :aria-label="`Remove ${t}`" @click="f.triggers.splice(i, 1)">✕</button></span>
            <input v-model="newTrigger" class="input w-36 py-1.5" placeholder="add word" @keydown.enter.prevent="addTrigger" >
          </div>
          <p class="mt-2 text-xs text-muted">Understood formats: <span v-for="e in examples" :key="e" class="mr-1 inline-block rounded bg-paper px-1.5 font-mono">{{ e }}</span></p>
        </div>
        <label class="flex items-start gap-2 text-sm">
          <input v-model="f.require_trigger" type="checkbox" class="mt-0.5 size-4 accent-brand-500">
          <span>Only accept comments that include a trigger word <span class="block text-xs text-muted">Recommended for busy lives. When off, “A01 2” also orders — but questions like “A01 ราคาเท่าไหร่?” are always ignored.</span></span>
        </label>
        <div class="grid gap-3 sm:grid-cols-3">
          <div><label class="label">Reserve stock for (hours)</label><input v-model.number="f.hold_hours" type="number" min="1" max="336" class="input" ></div>
          <div><label class="label">Max per item per customer</label><input v-model.number="f.max_qty" type="number" min="1" max="999" class="input" ></div>
          <div><label class="label">Shipping fee ({{ cur }})</label><input v-model="f.shipping" type="number" min="0" step="0.01" class="input" ></div>
        </div>
      </div>

      <div class="card space-y-4 p-6">
        <div class="font-bold">Automatic replies</div>
        <p class="text-xs text-muted">Placeholders: <code>{name}</code> <code>{items}</code> <code>{total}</code> <code>{link}</code> <code>{hours}</code> <code>{order}</code></p>
        <div>
          <label class="label">When items are reserved</label>
          <textarea v-model="f.reply_template" rows="3" class="input" />
          <div class="mt-1 rounded-xl bg-paper p-2 text-xs"><b>Preview:</b> {{ fill(f.reply_template) }}</div>
        </div>
        <div>
          <label class="label">When sold out</label>
          <textarea v-model="f.soldout_template" rows="2" class="input" />
          <div class="mt-1 rounded-xl bg-paper p-2 text-xs"><b>Preview:</b> {{ fill(f.soldout_template) }}</div>
        </div>
        <div>
          <label class="label">Payment instructions (shown on the checkout page)</label>
          <textarea v-model="f.payment_instructions" rows="3" class="input" placeholder="PromptPay 081-234-5678 (Siam Crafts Co., Ltd.) · Kasikorn 123-4-56789-0" />
        </div>
      </div>
      <p v-if="msg" class="text-sm text-mint-500">{{ msg }}</p>
      <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
      <button class="btn-primary">Save settings</button>
    </form>
  </div>
</template>
