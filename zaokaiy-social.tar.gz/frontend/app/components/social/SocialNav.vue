<script setup lang="ts">
const route = useRoute()
const tabs = [
  { to: '/dashboard/social', label: 'Live board' },
  { to: '/dashboard/social/orders', label: 'Social orders' },
  { to: '/dashboard/social/channels', label: 'Channels' },
  { to: '/dashboard/social/settings', label: 'Settings' },
]
const active = (to: string) => (to === '/dashboard/social' ? route.path === to : route.path.startsWith(to))
</script>

<template>
  <nav class="mb-6 flex gap-1 overflow-x-auto border-b border-line">
    <NuxtLink v-for="t in tabs" :key="t.to" :to="t.to" class="-mb-px whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-semibold transition" :class="active(t.to) ? 'border-brand-500 text-ink' : 'border-transparent text-muted hover:text-ink'">
      {{ t.label }}
    </NuxtLink>
  </nav>
</template>
