//! Commerce sales for the finance core's tax filings (amounts as charged, VAT included if any).

use chrono::NaiveDate;
use kernel::{
    core::{TaxSource, TaxableLine},
    error::AppResult,
    AppState, BoxFut,
};
use uuid::Uuid;


async fn lines(st: &AppState, sql: &str, from: NaiveDate, to: NaiveDate, shop: Option<Uuid>) -> AppResult<Vec<TaxableLine>> {
    let rows: Vec<(Uuid, String, i64, i64)> = sqlx::query_as(sql).bind(from).bind(to).bind(shop).fetch_all(&st.db).await?;
    Ok(rows
        .into_iter()
        .map(|(shop_id, currency, gross_cents, count)| TaxableLine { shop_id, currency, gross_cents, count })
        .collect())
}

/// Online orders (paid, shipped or completed), goods value per supplier shop. Shipping is excluded.
pub struct Orders;
impl TaxSource for Orders {
    fn key(&self) -> &'static str {
        "commerce.orders"
    }
    fn label(&self) -> &'static str {
        "Online orders"
    }
    fn taxable<'a>(&'a self, st: &'a AppState, from: NaiveDate, to: NaiveDate, shop: Option<Uuid>) -> BoxFut<'a, AppResult<Vec<TaxableLine>>> {
        Box::pin(lines(
            st,
            "SELECT oi.supplier_shop_id, o.currency, SUM(oi.unit_price_cents * oi.qty)::bigint, COUNT(DISTINCT o.id)
             FROM order_items oi JOIN orders o ON o.id = oi.order_id
             WHERE o.status IN ('paid','shipped','completed')
               AND (o.created_at AT TIME ZONE 'Asia/Vientiane')::date >= $1 AND (o.created_at AT TIME ZONE 'Asia/Vientiane')::date < $2
               AND ($3::uuid IS NULL OR oi.supplier_shop_id = $3)
             GROUP BY 1, 2",
            from,
            to,
            shop,
        ))
    }
}

/// Comment / chat orders (paid, shipped or completed), goods subtotal.
pub struct SocialOrders;
impl TaxSource for SocialOrders {
    fn key(&self) -> &'static str {
        "commerce.social"
    }
    fn label(&self) -> &'static str {
        "Social orders"
    }
    fn taxable<'a>(&'a self, st: &'a AppState, from: NaiveDate, to: NaiveDate, shop: Option<Uuid>) -> BoxFut<'a, AppResult<Vec<TaxableLine>>> {
        Box::pin(lines(
            st,
            "SELECT shop_id, currency, SUM(subtotal_cents)::bigint, COUNT(*)
             FROM social_orders
             WHERE status IN ('paid','shipped','completed')
               AND (created_at AT TIME ZONE 'Asia/Vientiane')::date >= $1 AND (created_at AT TIME ZONE 'Asia/Vientiane')::date < $2
               AND ($3::uuid IS NULL OR shop_id = $3)
             GROUP BY 1, 2",
            from,
            to,
            shop,
        ))
    }
}

/// Counter (POS) sales that were not voided.
pub struct PosSales;
impl TaxSource for PosSales {
    fn key(&self) -> &'static str {
        "commerce.pos"
    }
    fn label(&self) -> &'static str {
        "Counter sales (POS)"
    }
    fn taxable<'a>(&'a self, st: &'a AppState, from: NaiveDate, to: NaiveDate, shop: Option<Uuid>) -> BoxFut<'a, AppResult<Vec<TaxableLine>>> {
        Box::pin(lines(
            st,
            "SELECT shop_id, currency, SUM(total_cents)::bigint, COUNT(*)
             FROM pos_sales
             WHERE status = 'completed'
               AND (created_at AT TIME ZONE 'Asia/Vientiane')::date >= $1 AND (created_at AT TIME ZONE 'Asia/Vientiane')::date < $2
               AND ($3::uuid IS NULL OR shop_id = $3)
             GROUP BY 1, 2",
            from,
            to,
            shop,
        ))
    }
}
