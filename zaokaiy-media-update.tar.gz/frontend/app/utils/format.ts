export function money(cents: number | null | undefined, currency = 'THB') {
  const v = (cents ?? 0) / 100
  try {
    return new Intl.NumberFormat(currency === 'THB' ? 'th-TH' : 'en-US', {
      style: 'currency',
      currency,
      maximumFractionDigits: v % 1 === 0 ? 0 : 2,
    }).format(v)
  } catch {
    return `${v.toFixed(2)} ${currency}`
  }
}

export const pct = (bps: number | null | undefined) => `${((bps ?? 0) / 100).toFixed(bps && bps % 100 ? 1 : 0)}%`

export function ago(iso: string) {
  const s = (Date.now() - new Date(iso).getTime()) / 1000
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  if (s < 86400 * 30) return `${Math.floor(s / 86400)}d ago`
  return new Date(iso).toLocaleDateString()
}

export const shortId = (id: string) => id.slice(0, 8).toUpperCase()

export const kindLabel: Record<string, string> = {
  post: 'Post',
  caption: 'Caption',
  video_script: 'Video script',
  description: 'Description',
  ad_copy: 'Ad copy',
}

export function bytes(n: number | null | undefined) {
  const v = n ?? 0
  if (v < 1024) return `${v} B`
  if (v < 1024 ** 2) return `${(v / 1024).toFixed(0)} KB`
  if (v < 1024 ** 3) return `${(v / 1024 ** 2).toFixed(1)} MB`
  return `${(v / 1024 ** 3).toFixed(2)} GB`
}

export const isVideoUrl = (url: string | null | undefined) => !!url && /\.(mp4|webm|mov)(\?|#|$)/i.test(url)
