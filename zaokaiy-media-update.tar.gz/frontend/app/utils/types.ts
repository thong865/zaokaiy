export interface User {
  id: string
  email: string
  display_name: string
  role: 'user' | 'admin'
  created_at: string
}

export interface Shop {
  id: string
  owner_id: string
  slug: string
  name: string
  description: string
  logo_url: string | null
  currency: string
  kind: 'seller' | 'creator'
  created_at: string
}

export interface Product {
  id: string
  shop_id: string
  sku: string
  name: string
  description: string
  price_cents: number
  images: string[]
  category: string
  status: 'draft' | 'active' | 'archived'
  stock: number
  low_stock_threshold: number
  allow_resell: boolean
  commission_bps: number
  created_at: string
  updated_at: string
}

export interface CatalogProduct {
  id: string
  shop_id: string
  sku: string
  name: string
  description: string
  price_cents: number
  images: string[]
  category: string
  stock: number
  allow_resell: boolean
  commission_bps: number
  shop_slug: string
  shop_name: string
  currency: string
  via_shop_id: string | null
}

export interface CartLine {
  product_id: string
  via_shop_id: string | null
  name: string
  price_cents: number
  currency: string
  image: string | null
  shop_name: string
  qty: number
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  product_name: string
  supplier_shop_id: string
  seller_shop_id: string | null
  qty: number
  unit_price_cents: number
  commission_bps: number
  commission_cents: number
}

export interface Order {
  id: string
  buyer_id: string
  status: 'pending' | 'paid' | 'shipped' | 'completed' | 'cancelled'
  total_cents: number
  currency: string
  shipping_address: Record<string, string>
  created_at: string
  items: OrderItem[]
}

export interface Content {
  id: string
  shop_id: string
  product_id: string | null
  kind: 'post' | 'caption' | 'video_script' | 'description' | 'ad_copy'
  title: string
  body: string
  media_url: string | null
  ai_generated: boolean
  status: 'draft' | 'published'
  created_at: string
}

export interface AdCampaign {
  id: string
  shop_id: string
  product_id: string
  headline: string
  body: string
  image_url: string | null
  budget_cents: number
  cpc_cents: number
  spent_cents: number
  impressions: number
  clicks: number
  status: 'draft' | 'active' | 'paused' | 'ended'
  created_at: string
}

export interface Partnership {
  id: string
  supplier_shop_id: string
  supplier_name: string
  reseller_shop_id: string
  reseller_name: string
  status: 'pending' | 'approved' | 'rejected' | 'revoked'
  commission_bps: number | null
  message: string
  created_at: string
}

export interface MediaAsset {
  id: string
  shop_id: string
  kind: 'image' | 'video'
  source: 'upload' | 'url'
  mime: string
  url: string
  thumb_url: string | null
  size_bytes: number
  width: number | null
  height: number | null
  alt: string
  original_name: string
  created_at: string
  product_count?: number
  position?: number
}

export interface PublicMedia {
  id: string
  kind: 'image' | 'video'
  url: string
  thumb_url: string | null
  alt: string
  mime: string
  width: number | null
  height: number | null
}
