<script setup lang="ts">
import type { MediaAsset, Product } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const route = useRoute()
const api = useApi()
const { shopId, shop } = useShop()
const { data: product, refresh } = await useAsyncData(`product-edit:${route.params.id}`, () => api<Product>(`/products/${route.params.id}`))
const { data: gallery } = await useAsyncData(`product-media:${route.params.id}`, () => api<MediaAsset[]>(`/products/${route.params.id}/media`), { default: () => [] })
const form = ref<{ f: { description: string } } | null>(null)
const busy = ref(false)
const msg = ref('')
const error = ref('')

async function save(body: Record<string, unknown>) {
  busy.value = true
  error.value = ''
  msg.value = ''
  try {
    product.value = await api<Product>(`/products/${route.params.id}`, { method: 'PATCH', body })
    msg.value = 'Saved'
  } catch (e) {
    error.value = apiError(e)
  } finally {
    busy.value = false
  }
}

const ai = reactive({ busy: false, tone: 'friendly and energetic', language: 'English' })
async function writeDescription() {
  ai.busy = true
  error.value = ''
  try {
    const r = await api<{ body: string }>(`/shops/${shopId.value}/ai/generate`, {
      method: 'POST',
      body: { product_id: route.params.id, kind: 'description', tone: ai.tone, language: ai.language },
    })
    if (form.value) form.value.f.description = r.body
  } catch (e) {
    error.value = apiError(e)
  } finally {
    ai.busy = false
  }
}

const stock = reactive({ delta: 10, reason: 'restock', note: '' })
async function adjust() {
  error.value = ''
  try {
    await api(`/products/${route.params.id}/stock`, { method: 'POST', body: { ...stock, delta: Number(stock.delta) } })
    await refresh()
    msg.value = 'Stock updated'
  } catch (e) {
    error.value = apiError(e)
  }
}
</script>

<template>
  <div v-if="product">
    <NuxtLink to="/dashboard/products" class="text-sm text-muted hover:text-ink">← Products</NuxtLink>
    <div class="mb-6 mt-2 flex flex-wrap items-center gap-3">
      <h1 class="page-title">{{ product.name }}</h1>
      <StatusBadge :status="product.status" />
      <NuxtLink v-if="product.status === 'active'" :to="`/p/${product.id}`" target="_blank" class="ml-auto text-sm font-semibold text-brand-600 hover:underline">View live ↗</NuxtLink>
    </div>
    <ProductForm :key="product.updated_at" ref="form" :product="product" :busy="busy" :currency="shop?.currency" @submit="save">
      <template #media>
        <MediaGalleryEditor v-model="gallery" :shop-id="product.shop_id" :product-id="product.id" />
      </template>
      <template #description-tools>
        <div class="mb-1.5 flex items-center gap-2">
          <select v-model="ai.language" class="rounded-lg border border-line bg-white px-2 py-1 text-xs">
            <option>English</option><option>Thai</option><option>Lao</option><option>Vietnamese</option><option>Chinese</option>
          </select>
          <button type="button" class="btn-dark btn-sm" :disabled="ai.busy" @click="writeDescription">{{ ai.busy ? 'Writing…' : '✦ Write with AI' }}</button>
        </div>
      </template>
      <template #after>
        <p v-if="msg" class="text-sm text-mint-500">{{ msg }}</p>
        <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
        <div class="card space-y-3 p-5">
          <div class="font-bold">Adjust stock</div>
          <div class="flex gap-2">
            <input v-model="stock.delta" type="number" class="input w-24" >
            <select v-model="stock.reason" class="input"><option value="restock">Restock</option><option value="adjust">Adjust</option><option value="return">Return</option></select>
          </div>
          <input v-model="stock.note" placeholder="Note (optional)" class="input" >
          <button type="button" class="btn-ghost w-full" @click="adjust">Apply</button>
        </div>
        <NuxtLink :to="{ path: '/dashboard/content', query: { product: product.id } }" class="btn-ghost w-full">✎ Create content for this</NuxtLink>
      </template>
    </ProductForm>
  </div>
</template>
