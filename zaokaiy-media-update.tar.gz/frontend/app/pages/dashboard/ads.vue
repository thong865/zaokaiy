<script setup lang="ts">
import type { AdCampaign } from '~/utils/types'

definePageMeta({ layout: 'dashboard', middleware: 'seller' })
const api = useApi()
const { shopId, shop } = useShop()
const { data: ads, refresh } = await useAsyncData('ads-list', () => api<AdCampaign[]>(`/shops/${shopId.value}/ads`), { watch: [shopId], default: () => [] })
const { data: sellable } = await useSellable()
const cur = computed(() => shop.value?.currency ?? 'THB')
const name = (id: string) => sellable.value.find((s) => s.id === id)?.name ?? 'Product'

const show = ref(false)
const f = reactive({ product_id: '', headline: '', body: '', image_url: '', budget: 500, cpc: 2, status: 'active' })
const error = ref('')
const aiBusy = ref(false)
async function aiCopy() {
  if (!f.product_id) return (error.value = 'Choose a product first')
  aiBusy.value = true
  error.value = ''
  try {
    const r = await api<{ title: string; body: string }>(`/shops/${shopId.value}/ai/generate`, { method: 'POST', body: { product_id: f.product_id, kind: 'ad_copy' } })
    f.headline = r.title.slice(0, 80)
    f.body = r.body.replace(/\n\n\[offline template.*$/s, '').slice(0, 200)
  } catch (e) {
    error.value = apiError(e)
  } finally {
    aiBusy.value = false
  }
}
async function create() {
  error.value = ''
  try {
    await api(`/shops/${shopId.value}/ads`, {
      method: 'POST',
      body: { product_id: f.product_id, headline: f.headline, body: f.body, image_url: f.image_url || null, budget_cents: Math.round(f.budget * 100), cpc_cents: Math.round(f.cpc * 100), status: f.status },
    })
    show.value = false
    Object.assign(f, { product_id: '', headline: '', body: '', image_url: '' })
    await refresh()
  } catch (e) {
    error.value = apiError(e)
  }
}
async function setStatus(a: AdCampaign, status: string) {
  try {
    await api(`/ads/${a.id}`, { method: 'PATCH', body: { status } })
    await refresh()
  } catch (e) {
    error.value = apiError(e)
  }
}
</script>

<template>
  <div>
    <div class="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 class="page-title">Ads</h1>
        <p class="text-sm text-muted">Promote your own or resold products across the marketplace. You pay per click; campaigns stop when the budget runs out.</p>
      </div>
      <button class="btn-primary" @click="show = true">+ New campaign</button>
    </div>
    <p v-if="error && !show" class="mt-3 text-sm text-brand-700">{{ error }}</p>

    <div v-if="ads.length" class="card mt-6 overflow-x-auto">
      <table class="table">
        <thead><tr><th>Campaign</th><th>Budget</th><th>Impr.</th><th>Clicks</th><th>CTR</th><th>Status</th><th /></tr></thead>
        <tbody>
          <tr v-for="a in ads" :key="a.id">
            <td><div class="font-semibold">{{ a.headline }}</div><div class="text-xs text-muted">{{ name(a.product_id) }} · {{ money(a.cpc_cents, cur) }}/click</div></td>
            <td>
              <div class="text-xs">{{ money(a.spent_cents, cur) }} / {{ money(a.budget_cents, cur) }}</div>
              <div class="mt-1 h-1.5 w-28 rounded-full bg-line"><div class="h-full rounded-full bg-brand-500" :style="{ width: `${Math.min(100, (a.spent_cents / a.budget_cents) * 100)}%` }" /></div>
            </td>
            <td>{{ a.impressions }}</td>
            <td>{{ a.clicks }}</td>
            <td>{{ a.impressions ? ((a.clicks / a.impressions) * 100).toFixed(1) + '%' : '—' }}</td>
            <td><StatusBadge :status="a.status" /></td>
            <td class="whitespace-nowrap text-right">
              <button v-if="a.status === 'active'" class="btn-ghost btn-sm" @click="setStatus(a, 'paused')">Pause</button>
              <button v-else-if="a.status !== 'ended'" class="btn-primary btn-sm" @click="setStatus(a, 'active')">Activate</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <EmptyState v-else class="mt-6" title="No campaigns yet" text="Ads appear on the marketplace home page for shoppers." />

    <div v-if="show" class="fixed inset-0 z-50 grid place-items-center bg-ink/40 p-4" @click.self="show = false">
      <form class="card w-full max-w-lg space-y-4 p-6 shadow-2xl" @submit.prevent="create">
        <div class="text-lg font-bold">New campaign</div>
        <div>
          <label class="label">Product</label>
          <select v-model="f.product_id" required class="input">
            <option value="" disabled>Choose…</option>
            <option v-for="s in sellable" :key="s.id" :value="s.id">{{ s.name }}{{ s.resold ? ' (resold)' : '' }}</option>
          </select>
        </div>
        <div>
          <div class="flex items-center justify-between"><label class="label">Headline</label><button type="button" class="mb-1.5 text-xs font-semibold text-brand-600" :disabled="aiBusy" @click="aiCopy">{{ aiBusy ? 'Writing…' : '✦ Write with AI' }}</button></div>
          <input v-model="f.headline" required maxlength="80" class="input" >
        </div>
        <div><label class="label">Body</label><textarea v-model="f.body" rows="2" maxlength="200" class="input" /></div>
        <MediaField v-model="f.image_url" :shop-id="shopId" kind="image" label="Ad image (defaults to product cover)" />
        <div class="grid grid-cols-3 gap-3">
          <div><label class="label">Budget</label><input v-model.number="f.budget" type="number" min="1" step="1" class="input" ></div>
          <div><label class="label">Per click</label><input v-model.number="f.cpc" type="number" min="0.01" step="0.01" class="input" ></div>
          <div><label class="label">Start as</label><select v-model="f.status" class="input"><option value="active">Active</option><option value="draft">Draft</option></select></div>
        </div>
        <p class="text-xs text-muted">≈ {{ Math.floor(f.budget / (f.cpc || 1)) }} clicks for {{ money(f.budget * 100, cur) }}</p>
        <p v-if="error" class="text-sm text-brand-700">{{ error }}</p>
        <div class="flex justify-end gap-2"><button type="button" class="btn-ghost" @click="show = false">Cancel</button><button class="btn-primary">Create</button></div>
      </form>
    </div>
  </div>
</template>
