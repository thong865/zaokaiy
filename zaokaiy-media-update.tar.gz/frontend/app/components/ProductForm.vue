<script setup lang="ts">
import type { Product } from '~/utils/types'

const props = defineProps<{ product?: Product | null; busy?: boolean; currency?: string }>()
const emit = defineEmits<{ submit: [body: Record<string, unknown>] }>()

const f = reactive({
  sku: props.product?.sku ?? '',
  name: props.product?.name ?? '',
  description: props.product?.description ?? '',
  price: props.product ? props.product.price_cents / 100 : 0,
  category: props.product?.category ?? 'general',
  status: props.product?.status ?? 'active',
  initial_stock: 0,
  low_stock_threshold: props.product?.low_stock_threshold ?? 5,
  allow_resell: props.product?.allow_resell ?? false,
  commission: (props.product?.commission_bps ?? 1000) / 100,
})
watch(() => props.product?.description, (d) => { if (d !== undefined) f.description = d })

function submit() {
  const body: Record<string, unknown> = {
    name: f.name,
    description: f.description,
    price_cents: Math.round(Number(f.price) * 100),
    category: f.category.trim().toLowerCase() || 'general',
    status: f.status,
    low_stock_threshold: Number(f.low_stock_threshold),
    allow_resell: f.allow_resell,
    commission_bps: Math.round(Number(f.commission) * 100),
  }
  if (!props.product) {
    body.sku = f.sku
    body.initial_stock = Number(f.initial_stock)
  }
  emit('submit', body)
}
const perUnit = computed(() => Math.floor(Number(f.price) * 100 * Number(f.commission) / 100))
defineExpose({ f })
</script>

<template>
  <form class="grid gap-6 lg:grid-cols-[1fr_320px]" @submit.prevent="submit">
    <div class="card space-y-4 p-6">
      <div class="grid gap-4 sm:grid-cols-[1fr_180px]">
        <div><label class="label">Name</label><input v-model="f.name" required class="input" ></div>
        <div><label class="label">SKU</label><input v-model="f.sku" :disabled="!!product" required class="input disabled:bg-paper" ></div>
      </div>
      <div>
        <div class="flex items-center justify-between"><label class="label">Description</label><slot name="description-tools" /></div>
        <textarea v-model="f.description" rows="8" class="input" />
      </div>
      <slot name="media" />
      <div class="grid gap-4 sm:grid-cols-3">
        <div><label class="label">Price ({{ currency ?? 'THB' }})</label><input v-model="f.price" type="number" min="0" step="0.01" required class="input" ></div>
        <div><label class="label">Category</label><input v-model="f.category" class="input" ></div>
        <div>
          <label class="label">Status</label>
          <select v-model="f.status" class="input"><option value="draft">Draft</option><option value="active">Active</option><option value="archived">Archived</option></select>
        </div>
      </div>
    </div>
    <div class="space-y-4">
      <div class="card space-y-4 p-5">
        <div class="font-bold">Inventory</div>
        <div v-if="!product"><label class="label">Initial stock</label><input v-model="f.initial_stock" type="number" min="0" class="input" ></div>
        <div v-else class="text-sm">In stock: <b>{{ product.stock }}</b> <NuxtLink to="/dashboard/inventory" class="text-brand-600 underline">adjust</NuxtLink></div>
        <div><label class="label">Low-stock alert at</label><input v-model="f.low_stock_threshold" type="number" min="0" class="input" ></div>
      </div>
      <div class="card space-y-4 p-5">
        <label class="flex items-center justify-between gap-3">
          <span><span class="font-bold">Open to sell-staff</span><br><span class="text-xs text-muted">Let approved shops & creators resell this.</span></span>
          <input v-model="f.allow_resell" type="checkbox" class="size-5 accent-brand-500" >
        </label>
        <div v-if="f.allow_resell">
          <label class="label">Default commission (%)</label>
          <input v-model="f.commission" type="number" min="0" max="90" step="0.5" class="input" >
          <p class="mt-1 text-xs text-muted">≈ {{ money(perUnit, currency) }} per unit. You can set a custom rate per sell-staff.</p>
        </div>
      </div>
      <button class="btn-primary w-full" :disabled="busy">{{ busy ? 'Saving…' : product ? 'Save changes' : 'Create product' }}</button>
      <slot name="after" />
    </div>
  </form>
</template>
