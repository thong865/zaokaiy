# zaokaiy — social commerce platform

Sellers open shops and manage products and inventory. They can open their catalog to **sell-staff**: other shops and content creators who resell those products in their own storefront and earn a commission the supplier sets. Ads, a creator content studio, and an AI agent help everyone grow.

| Layer | Stack |
|---|---|
| Backend | Rust · Axum 0.8 · SQLx 0.8 (Postgres) · JWT + Argon2 · Anthropic Messages API |
| Frontend | Nuxt 4 · Vue 3 · Tailwind CSS v4 |
| Database | PostgreSQL 16. Migrations are embedded and run automatically when the API starts. |

## Quick start

### Option A: Docker (everything)
```bash
docker compose up --build
python scripts/seed.py            # optional demo data
```
Open http://localhost:3000. The API runs at http://localhost:8080/api.

### Option B: Local dev
```bash
# 1. Postgres
docker compose up -d db

# 2. API
cd backend
cp .env.example .env              # add ANTHROPIC_API_KEY to enable the AI features
cargo run

# 3. Web (new terminal)
cd frontend
npm install
npm run dev                       # http://localhost:3000

# 4. Demo data + tests (new terminal, from the repo root)
python scripts/seed.py
python scripts/smoke_test.py
python scripts/media_test.py
```
Demo logins (password `password123`): `siam@demo.dev`, `lanna@demo.dev` (suppliers), `bee@demo.dev` (creator/sell-staff), `buyer@demo.dev`.

## Core concepts

**Shop.** One account can own many shops. `kind` is `seller` (own products) or `creator` (mostly resells).

**Product & inventory.** `stock` changes only in transactions, and every change writes an `inventory_movements` row with a reason: `restock`, `sale`, `adjust`, `return` or `cancel`. There are low-stock alerts per product.

**Sell-staff program:**
1. The supplier turns on `allow_resell` for a product and sets a default `commission_bps` (1000 = 10%).
2. A reseller shop requests a **partnership** with the supplier shop.
3. The supplier approves it and can give that reseller a custom rate.
4. The reseller adds **listings** to its storefront. Shoppers who buy through `/p/:id?via=<reseller_shop_id>` credit the reseller.
5. Checkout locks the product rows, reserves stock, creates one order per supplier, and writes a **commission** row (`pending`).
6. When the order is `completed`, the commission becomes `approved`, and the supplier marks it `paid`. If the order is cancelled, the stock is returned and the commission becomes `void`.
7. There is no self-commission: a reseller who buys through their own storefront earns nothing.

**Media library.** Each shop has its own library of images and videos. You upload a file once and can reuse it in product galleries, creator posts and ads.
- Uploads are checked by their actual file content, not the file name. Photos are rotated using their camera orientation, shrunk to at most 2000 px, re-encoded (which strips GPS and other camera data) and given a 480 px thumbnail. Animated GIFs are kept as they are.
- Videos (MP4, WebM, MOV) get a poster frame when `ffmpeg` is installed.
- A product gallery holds up to 15 items and can be reordered; the first item is the cover. `products.images` is kept in sync with the gallery for catalog listings.
- Deleting an item that is still used is blocked (409) unless you pass `force`, which removes it from every product, post and ad.
- Storage is either `local` (disk, served at `/media`) or `s3` (AWS, MinIO, R2). See `backend/.env.example`.

**Ads.** CPC campaigns on your own or resold products. `/ads/serve` records impressions. `/ads/:id/click` charges the CPC and ends the campaign automatically when the budget runs out.

**Creator content.** Posts, captions, video scripts, descriptions and ad copy. Published posts appear in `/feed` with shoppable links that credit the creator's shop.

**AI:**
- `POST /shops/:id/ai/generate` writes content for a product in any tone or language, and can save it as a draft.
- `POST /shops/:id/ai/agent` is a tool-using assistant. It can read stats, products, low stock, orders and sell-staff requests, and it can create **drafts** of content and ad campaigns. It never publishes anything or spends money by itself.
- If `ANTHROPIC_API_KEY` is not set, both endpoints fall back to offline templates, so the platform still works.

## API map (`/api`)
```
auth         POST /auth/register · POST /auth/login · GET /auth/me
catalog      GET /catalog/products · GET /catalog/products/:id?via= · GET /catalog/categories
             GET /storefront/:slug · GET /feed/contents · GET /ads/serve · POST /ads/:id/click
shops        GET /me/shops · POST /shops · PATCH /shops/:id · GET /shops/:id/stats
products     GET|POST /shops/:id/products · GET|PATCH|DELETE /products/:id
inventory    POST /products/:id/stock · GET /shops/:id/inventory/movements · GET /shops/:id/inventory/low-stock
sell-staff   GET /marketplace/products · GET|POST /shops/:id/partnerships
             POST /partnerships/:id/decision · POST /partnerships/:id/revoke
             GET|POST /shops/:id/listings · DELETE /listings/:id
commissions  GET /shops/:id/commissions · GET /shops/:id/commissions/payable · POST /commissions/:id/pay
orders       POST /orders/checkout · GET /orders · GET /orders/:id · POST /orders/:id/pay · POST /orders/:id/cancel
             GET /shops/:id/sales?role=supplier|seller · POST /shops/:id/orders/:order_id/status
ads          GET|POST /shops/:id/ads · PATCH /ads/:id
content      GET|POST /shops/:id/contents · PATCH|DELETE /contents/:id
media        GET /shops/:id/media · POST /shops/:id/media/upload[?product_id=] (multipart `file`)
             POST /shops/:id/media/url · POST /shops/:id/media/delete · GET|PATCH|DELETE /media/:id[?force=true]
             GET|PUT /products/:id/media   (PUT {asset_ids:[…]} = full ordered gallery)
ai           GET /ai/status · POST /shops/:id/ai/generate · POST /shops/:id/ai/agent
```

## Project layout
```
backend/
  migrations/0001_init.sql     schema
  src/main.rs                  bootstrap, CORS, migrations
  src/auth.rs                  JWT, Argon2, AuthUser extractor
  src/ai.rs                    content generation + agent tool loop
  src/media.rs · storage.rs    image processing · local/S3 storage
  src/routes/*.rs              one module per domain
frontend/app/
  pages/                       storefront, product, cart, orders, feed, dashboard/*
  components/ composables/     UI kit, useApi/useAuth/useCart/useShop
scripts/seed.py · smoke_test.py
```

## Production checklist / next steps
- **Payments:** `POST /orders/:id/pay` is a mock. Replace it with a PSP webhook (PromptPay/Omise/Stripe) and settle commissions through payouts.
- **Media:** use a CDN in front of `MEDIA_PUBLIC_URL`, move video transcoding (HLS) to a background worker, and add per-shop storage quotas.
- Set a strong `JWT_SECRET`, use HTTPS, and add rate limiting (for example `tower_governor`) on auth and ad-click endpoints.
- Ad-click fraud protection (dedupe per visitor/IP), plus search with Postgres FTS or Meilisearch.
- Shipping integrations (Kerry, Flash, Thailand Post), plus PDPA consent and data-export tooling.
