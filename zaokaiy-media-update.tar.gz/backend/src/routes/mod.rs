use axum::{
    extract::DefaultBodyLimit,
    http::{header, HeaderValue},
    routing::{delete, get, patch, post},
    Json, Router,
};
use serde_json::json;
use tower::ServiceBuilder;
use tower_http::{services::ServeDir, set_header::SetResponseHeaderLayer};
use uuid::Uuid;

use crate::{
    auth::AuthUser,
    error::{AppError, AppResult},
    models::Shop,
    AppState,
};

mod ads;
mod ai_routes;
mod auth_routes;
mod catalog;
mod content;
mod inventory;
pub mod media;
mod orders;
mod partners;
mod products;
mod shops;
mod stats;

pub use content::{
    insert as content_insert, CreateContent as CreateContentReq, KINDS as CONTENT_KINDS,
};
pub use stats::compute as stats_compute;

pub fn router(state: AppState) -> Router {
    let upload_limit = (state.cfg.media_max_video_mb.max(state.cfg.media_max_image_mb) + 10) * 1_048_576;
    let api = Router::new()
        .route("/health", get(|| async { Json(json!({ "ok": true })) }))
        // auth
        .route("/auth/register", post(auth_routes::register))
        .route("/auth/login", post(auth_routes::login))
        .route("/auth/me", get(auth_routes::me))
        // public catalog / storefronts
        .route("/catalog/products", get(catalog::list_products))
        .route("/catalog/products/{id}", get(catalog::get_product))
        .route("/catalog/categories", get(catalog::categories))
        .route("/storefront/{slug}", get(catalog::storefront))
        .route("/feed/contents", get(content::public_feed))
        .route("/ads/serve", get(ads::serve))
        .route("/ads/{id}/click", post(ads::click))
        // shops
        .route("/me/shops", get(shops::my_shops))
        .route("/shops", post(shops::create_shop))
        .route("/shops/{id}", patch(shops::update_shop))
        .route("/shops/{id}/stats", get(stats::shop_stats))
        // products & inventory
        .route(
            "/shops/{id}/products",
            get(products::list_for_shop).post(products::create),
        )
        .route(
            "/products/{id}",
            get(products::get_owned)
                .patch(products::update)
                .delete(products::archive),
        )
        .route("/products/{id}/stock", post(inventory::adjust_stock))
        .route("/shops/{id}/inventory/movements", get(inventory::movements))
        .route("/shops/{id}/inventory/low-stock", get(inventory::low_stock))
        // reseller program
        .route("/marketplace/products", get(partners::marketplace))
        .route(
            "/shops/{id}/partnerships",
            get(partners::list).post(partners::request),
        )
        .route("/partnerships/{id}/decision", post(partners::decide))
        .route("/partnerships/{id}/revoke", post(partners::revoke))
        .route(
            "/shops/{id}/listings",
            get(partners::listings).post(partners::add_listing),
        )
        .route("/listings/{id}", delete(partners::remove_listing))
        .route("/shops/{id}/commissions", get(partners::commissions_earned))
        .route(
            "/shops/{id}/commissions/payable",
            get(partners::commissions_payable),
        )
        .route("/commissions/{id}/pay", post(partners::pay_commission))
        // orders
        .route("/orders/checkout", post(orders::checkout))
        .route("/orders", get(orders::my_orders))
        .route("/orders/{id}", get(orders::get_order))
        .route("/orders/{id}/pay", post(orders::pay))
        .route("/orders/{id}/cancel", post(orders::cancel))
        .route("/shops/{id}/sales", get(orders::shop_sales))
        .route(
            "/shops/{id}/orders/{order_id}/status",
            post(orders::set_status),
        )
        // ads
        .route("/shops/{id}/ads", get(ads::list).post(ads::create))
        .route("/ads/{id}", patch(ads::update))
        // creator content
        .route(
            "/shops/{id}/contents",
            get(content::list).post(content::create),
        )
        .route(
            "/contents/{id}",
            patch(content::update).delete(content::remove),
        )
        // AI
        .route("/ai/status", get(ai_routes::status))
        .route("/shops/{id}/ai/generate", post(ai_routes::generate))
        .route("/shops/{id}/ai/agent", post(ai_routes::agent))
        // media library
        .route("/shops/{id}/media", get(media::list))
        .route(
            "/shops/{id}/media/upload",
            post(media::upload).layer(DefaultBodyLimit::max(upload_limit)),
        )
        .route("/shops/{id}/media/url", post(media::add_url))
        .route("/shops/{id}/media/delete", post(media::bulk_remove))
        .route("/media/{id}", get(media::get_one).patch(media::update).delete(media::remove))
        .route("/products/{id}/media", get(media::get_gallery).put(media::set_gallery));

    let mut app = Router::new().nest("/api", api);
    // Local driver: serve uploaded files. Keys are random UUIDs, so cache forever.
    if let Some(dir) = state.storage.local_dir() {
        let files = ServiceBuilder::new()
            .layer(SetResponseHeaderLayer::overriding(
                header::CACHE_CONTROL,
                HeaderValue::from_static("public, max-age=31536000, immutable"),
            ))
            .layer(SetResponseHeaderLayer::overriding(
                header::X_CONTENT_TYPE_OPTIONS,
                HeaderValue::from_static("nosniff"),
            ))
            .service(ServeDir::new(dir));
        app = app.nest_service("/media", files);
    }
    app.with_state(state)
}

/// Load a shop and ensure the caller owns it (admins bypass).
pub async fn owned_shop(state: &AppState, shop_id: Uuid, user: &AuthUser) -> AppResult<Shop> {
    let shop: Shop = sqlx::query_as("SELECT * FROM shops WHERE id = $1")
        .bind(shop_id)
        .fetch_optional(&state.db)
        .await?
        .ok_or(AppError::NotFound)?;
    if shop.owner_id != user.id && !user.is_admin() {
        return Err(AppError::Forbidden);
    }
    Ok(shop)
}

/// Load a product and ensure the caller owns its shop.
pub async fn owned_product(
    state: &AppState,
    product_id: Uuid,
    user: &AuthUser,
) -> AppResult<crate::models::Product> {
    let p: crate::models::Product = sqlx::query_as("SELECT * FROM products WHERE id = $1")
        .bind(product_id)
        .fetch_optional(&state.db)
        .await?
        .ok_or(AppError::NotFound)?;
    owned_shop(state, p.shop_id, user).await?;
    Ok(p)
}

pub fn commission_of(unit_price: i64, qty: i32, bps: i32) -> i64 {
    unit_price * qty as i64 * bps as i64 / 10_000
}
